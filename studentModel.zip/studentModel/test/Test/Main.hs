module Main where

import Test.HUnitPlus as UT

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map
import StudentModel.ProgressIndicators
import Scenarios.Vocabulary

import Test.PiTest
import Scenarios.Scen1Test
import Test.RuleTest
import Test.TenStepsTest
import DomainReasoners.LinEqTest

main :: IO ()
main = createMain [pitests, pscen1tests, trtests, tenstepstests, lineqtests]













