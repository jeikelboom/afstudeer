module Test.RuleTest where

import Test.HUnitPlus as UT

import Control.Monad.Trans.State.Strict
import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map
import Text.JSON.Generic

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.Vocabulary
import Scenarios.ScenarioExprEval

trtests = UT.testSuite "progress Indicators" [hasName01]

testit :: (Eq a, Show a) => String -> a -> a -> Test
testit tname expected outcome = tname ~: (assertEqual tname expected outcome)

-- fold function to collect names

lt04 = LearningTask{lt=learningTask04
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprDouble
                `with` rlExprGtr
                `with` rlExprIf
                `with` rlExprPlus
            )
            `with` (esStudent
                `with` dmExpressionEvaluation Comprehension
                `with` csCombined
            )}



hasName01= testit "apply01" True (apply lt04 (hasName "LT.04")  )









