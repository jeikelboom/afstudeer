module Test.TenStepsTest where


import Test.HUnitPlus as UT

import Control.Monad.Trans.State.Strict
import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map
import Text.JSON.Generic

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.Vocabulary
import Scenarios.ScenarioExprEval

tenstepstests = UT.testSuite "progress Indicators" [obj01
    , testa_w12_lt04, testb_w12_lt04, testc_w12_lt04, testa_w21_lt04, testb_w21_lt04, testc_w21_lt04
    , testobjectivesMetFalse, testobjectivesMetTrue
    ,test_updateStudentModel
    ]

testit :: (Eq a, Show a) => String -> a -> a -> Test
testit tname expected outcome = tname ~: (assertEqual tname expected outcome)


m30 = learningCurveId !! 30
tcs30  = getTaskClasses m30
tc30_01 = head $ filter (apply2 (hasName "TC.01")) tcs30
lts30 = getLearningTask tc30_01

gettc tcname w = head $ filter (apply2 (hasName tcname)) $  getTaskClasses (learningCurveId !! w)
getlt tcname ltname w = head $ filter (apply2 (hasName ltname)) $ getLearningTask $ gettc tcname w


w01_lt04 = getlt  "TC.01" "LT.04" 1

objectives' = getSuccessCriteria w01_lt04
obj01 = testit "obj01" rlExprMaxi (getValue [rlExprMaxi] $ getPrInd objectives')

getMdl w = learningCurveId !! w
getTC tcname w = head $ filter (apply2 (hasName tcname)) $  getTaskClasses (learningCurveId !! w)
getLT tcname ltname w = head $ filter (apply2 (hasName ltname)) $ getLearningTask $ getTC tcname w
arguments tcname ltname w = (getMdl w , Student PiBottom, getTC tcname w, getLT tcname ltname w)


--w12_lt04 = getLT  "TC.01" "LT.04" 12
testa_w12_lt04 = testit "w12_lt04a" False (evalPreds (arguments "TC.01" "LT.04" 12) [learningTaskState FINI, learningTaskHasErrors])
expected01 = mkValue (["ES.model", "TC.01", "LT.04"]) esError
testb_w12_lt04 = testit "w12_lt04b" expected01 (evalFacts (arguments "TC.01" "LT.04" 12) [taskInError])
testc_w12_lt04 = testit "w12_lt04c" PiBottom (executeRule (arguments "TC.01" "LT.04" 12) learningTaskErrorRule)


--w21_lt04 = getLT  "TC.01" "LT.04" 21
testa_w21_lt04 = testit "w21_lt04a" True (evalPreds (arguments "TC.01" "LT.04" 21) [learningTaskState FINI, learningTaskHasErrors])
expected21 = mkValue (["ES.model", "TC.01", "LT.04"]) esError
testb_w21_lt04 = testit "w21_lt04b" expected21 (evalFacts (arguments "TC.01" "LT.04" 21) [taskInError])
testc_w21_lt04 = testit "w21_lt04c" expected21 (executeRule (arguments "TC.01" "LT.04" 21) learningTaskErrorRule)

-- rule objectivesMet
-- lt06 rules not met
w12lt19 = getLT  "TC.01" "LT.19" 12
testobjectivesMetFalse = testit "testobjectivesMetFalse" False (evalPreds (arguments "TC.01" "LT.19" 12) [successCriteriaMet])
w12lt06 = getLT  "TC.01" "LT.06" 30
testobjectivesMetTrue = testit "testobjectivesMetTrue" True (evalPreds (arguments "TC.01" "LT.06" 30) [successCriteriaMet])

val1=evalFacts (arguments "TC.01" "LT.19" 12) [updateStudentModel]
expected1 = mkValue2 [esModel] (obj2student $ getPrInd $ getObjectives w12lt19)
test_updateStudentModel  = testit "test_updateStudentModel" expected1 val1


obj06 = getPrInd $ getSuccessCriteria w12lt06
rl06 = getPrInd $  getProgress w12lt06





--w13_lt04 = getLT  "TC.01" "LT.04" 13
--test_w13_lt04 = testit "w13_lt04" INIT (ltState w13_lt04)
--w14_lt04 = getLT  "TC.01" "LT.04" 14
--test_w14_lt04 = testit "w14_lt04" BUSY (ltState w14_lt04)
--w20_lt04 = getLT  "TC.01" "LT.04" 20
--test_w20_lt04 = testit "w20_lt04" BUSY (ltState w20_lt04)
--w21_lt04 = getLT  "TC.01" "LT.04" 21
--test_w21_lt04 = testit "w21_lt04" ERROR (ltState w21_lt04)



--test_w21_lt04 = testit "w21_lt04" ERROR (ltState w21_lt04)


