module Test.PiTest where


import Test.HUnitPlus as UT

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map
import Text.JSON.Generic

import StudentModel.ProgressIndicators

pitests = UT.testSuite "progress Indicators" [join01, meet01, leq01, leq02, leq02b,
    join03, meet03, leq03a, leq03b, join04, meet04, getvalue01, mkvalue01]
join01, join03 :: Test

pv03, pv03', pv04, pv04' :: PrInd
pv03   = mkSub "pv03"  `with` PiCount "a" 6 `with` PiCount "b" 9 `with` PiCount "c" 5
pv03'  = mkSub "pv03"  `with` PiCount "a" 6 `with` PiCount "b" 9 `with` PiCount "c" 5

pv04   = mkSub "pv04"  `with` PiCount "a" 3 `with` PiCount "b" 11 `with` PiCount "d" 11
pv04'  = mkSub "pv04"  `with` PiCount "a" 7 `with` PiCount "b" 3  `with` PiCount "c" 5
j04    = mkSub "pv04"  `with` PiCount "a" 7 `with` PiCount "b" 11 `with` PiCount "c" 5 `with` PiCount "d" 11
m04    = mkSub "pv04"   `with` PiCount "a" 3 `with` PiCount "b" 3
--j04   = PiPV $ Map.fromList [("a", PiCount 7), ("b", PiCount 11), ("c", PiCount 5), ("d", PiCount 11)]
--m04   = PiPV $ Map.fromList [("a", PiCount 3),  ("b", PiCount 3)]


testit :: (Eq a, Show a) => String -> a -> a -> Test
testit tname expected outcome = tname ~: (assertEqual tname expected outcome)

join01  = testit "join01"   (PiCount "x" 4)  (PiCount "x" 3 \/ PiCount "x" 4)
meet01  = testit "meet01"   (PiCount "x" 3)  (PiCount "x" 3 /\ PiCount "x" 4)
leq01   = testit "leq01"    True       (leq (PiCount "x" 3)  (PiCount "x" 4))
leq02   = testit "leq01"    False      (leq (PiCount "x" 5)  (PiCount "x" 4))
leq02b  = testit "leq01b"   True       (leq (PiCount "x" 5)  (PiCount "x" 5))
join03  = testit "Join03"   pv03       (pv03 \/ pv03')
meet03  = testit "meet03"   pv03       (pv03 /\ pv03')
leq03a  = testit "lq03a"    True       (leq pv03 pv03')
leq03b  = testit "lq03b"    True       (leq pv03' pv03)
join04  = testit "join04"   j04        (pv04 \/ pv04')
meet04  = testit "meet04"   m04        (pv04 /\ pv04')
leq04a  = testit "leq04a"   False      (leq pv04 pv04')
leq04b  = testit "leq04b"   False      (leq pv04' pv04)

pv04J = encodeJSON pv04

getvalue01 = testit "getvalue01" (PiCount "a" 6) (getValue [mkSub "pv03", PiCount "a" 1] pv03)

pv10 = mkValue ["l0", "l1", "l2", "l3"] (PiCount "x" 42)
pv11 = mkValue ["l0", "l1", "l2", "l3"] (PiCount "y" 43)
pv12 = mkValue ["l0", "l1", "l2", "l3"] (PiCount "z" 44)
pv13 = pv10 \/ pv11 \/ pv12

mkvalue01 = testit "mkvalue01" (PiCount "x" 42) (getValue [mkSub "l0", mkSub "l1", mkSub "l2", mkSub "l3", PiCount "x" 1] pv10)





