{-#LANGUAGE GADTs #-}
module Scenarios.Scen1Test where

import Test.HUnitPlus as UT

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.ScenarioExprEval

pscen1tests = UT.testSuite "progress Indicators" [scen1_01
    , test_w13_lt06, test_w15_lt06
    , test_w12_lt04, test_w13_lt04, test_w14_lt04, test_w21_lt04, test_w20_lt04
    ]
--join01, join03 :: Test

testit :: (Eq a, Show a) => String -> a -> a -> Test
testit tname expected outcome = tname ~: (assertEqual tname expected outcome)

--m0 = shj model

scen1_01 = testit "scen1_01" (PiCount "x" 1) (PiCount "x" 1) --(getValue [VC.tc01, VC.lt14, VC.esObjective, VC.rlExprGtr] model)

m30 = learningCurve !!30
tcs30  = getTaskClasses m30
tc30_01 = head $ filter (apply2 (hasName "TC.01")) tcs30
lts30 = getLearningTask tc30_01

getTC tcname w = head $ filter (apply2 (hasName tcname)) $  getTaskClasses (learningCurve !! w)
getLT tcname ltname w = head $ filter (apply2 (hasName ltname)) $ getLearningTask $ getTC tcname w

w13_lt06 = getLT  "TC.01" "LT.06" 13
test_w13_lt06 = testit "w13_lt06" INIT (ltState w13_lt06)
w15_lt06 = getLT  "TC.01" "LT.06" 14
test_w15_lt06 = testit "w15_lt06" READY (ltState w15_lt06)

w12_lt04 = getLT  "TC.01" "LT.04" 12
test_w12_lt04 = testit "w12_lt04" INIT (ltState w12_lt04)
w13_lt04 = getLT  "TC.01" "LT.04" 13
test_w13_lt04 = testit "w13_lt04" INIT (ltState w13_lt04)
w14_lt04 = getLT  "TC.01" "LT.04" 14
test_w14_lt04 = testit "w14_lt04" BUSY (ltState w14_lt04)
w20_lt04 = getLT  "TC.01" "LT.04" 20
test_w20_lt04 = testit "w20_lt04" BUSY (ltState w20_lt04)
w21_lt04 = getLT  "TC.01" "LT.04" 21
test_w21_lt04 = testit "w21_lt04" ERROR (ltState w21_lt04)

--lt4 = [lt | tca <- piList isTaskClass $ model m30, lt <- piList isLearningTask tca]

data HP where
    HP :: (HasPrInd a) =>  a ->  HP

lta = HP w12_lt04
tca = HP tc30_01
arr =[lta, tca]


