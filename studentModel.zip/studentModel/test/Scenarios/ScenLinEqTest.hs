module Scenarios.ScenLinEqTest where

import Test.HUnitPlus as UT

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.ScenarioLinEq


sclineqtests = UT.testSuite "progress Indicators" [buggypred01]
--join01, join03 :: Test

testit :: (Eq a, Show a) => String -> a -> a -> Test
testit tname expected outcome = tname ~: (assertEqual tname expected outcome)



testCurriculum = Model (linEqCurriculum \/ buggy5)
theStudent = Student $ getValue [esStudent]  $ getPrInd testCurriculum
theTC = TaskClass $ getValue [taskClass01]   $ getPrInd testCurriculum
theLT = LearningTask $ getValue [learningTask01]   $ getPrInd theTC

isBuggy = apply (testCurriculum, theStudent, theTC, theLT) learningTaskBuggy
buggypred01 = testit "buggypred01" True isBuggy
meetresult = getPrInd $ meetHPI (getFailureCritera theLT) (getBuggy theLT)