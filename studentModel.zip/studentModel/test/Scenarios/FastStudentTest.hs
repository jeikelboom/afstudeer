module Scenarios.FastStudentTest where


import Test.HUnitPlus as UT

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.FastStudent




