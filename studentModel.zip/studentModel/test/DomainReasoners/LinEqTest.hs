module DomainReasoners.LinEqTest where

import Test.HUnitPlus as UT

import Ideas.Common.Library as LB
import qualified Ideas.Service.State as ST
import Ideas.Service.BasicServices as BS
import Ideas.Service.Diagnose
import Ideas.Main.Default
import Data.Ratio
import Text.PrettyPrint as PR

import DomainReasoners.LineairEquations


lineqtests = UT.testSuite "progress Indicators"
    [ test1a, test1b, test1c, test1d, test1e
    , test2a, test2b, test2c, test2d, test2e
    , test3a, test3b, test3c, test3d, test3e
    , test4a, test4b, test4c, test4d, test4e
    , test5a, test5b, test5c, test5d, test5e
    , test5ab, test5bb,       test5db, test5eb
    , test6a, test6b, test6c, test6d, test6e]



linex1a = LE 6 1 0 22
linex1b = LE 4 2 0 20
problem0 = PR linex1a linex1b 3 4

Just problem1 = LB.apply canformX problem0
test1a = "problem1a" ~: (assertEqual "problem1a" "12x + 2y = 44\n12x + 6y = 60" (pp2 problem1))
test1b = "problem1b" ~: (assertEqual "problem1b" True (consistent problem1))
test1c = "problem1c" ~: (assertEqual "problem1c" (Just problem1) (LB.apply linStrategy problem0))
test1d = "problem1d" ~: (assertEqual "problem1d" True (similar problem0 problem1))
test1e = "problem1e" ~: (assertEqual "problem1d" False (isDone problem1))

Just problem2 = LB.apply eliminateXY1 problem1
test2a = "problem2a" ~: (assertEqual "problem2a" "12x + 2y = 44\n4y = 16" (pp2 problem2))
test2b = "problem2b" ~: (assertEqual "problem2b" True (consistent problem2))
test2c = "problem2c" ~: (assertEqual "problem2c" (Just problem2) (LB.apply linStrategy problem1))
test2d = "problem2d" ~: (assertEqual "problem2d" True (similar problem0 problem2))
test2e = "problem2e" ~: (assertEqual "problem2e" False (isDone problem2))

Just problem3 = LB.apply computeY problem2
test3a = "problem3a" ~: (assertEqual "problem3a" "12x + 2y = 44\ny = 4" (pp2 problem3))
test3b = "problem3c" ~: (assertEqual "problem3b" True (consistent problem3))
test3c = "problem3c" ~: (assertEqual "problem3c" (Just problem3) (LB.apply linStrategy problem2))
test3d = "problem3d" ~: (assertEqual "problem3d" True (similar problem0 problem3))
test3e = "problem3e" ~: (assertEqual "problem3e" False (isDone problem3))

Just problem4 = LB.apply substituteY problem3
test4a = "problem4a" ~: (assertEqual "problem4a" "12x + 8 = 44\ny = 4" (pp2 problem4))
test4b = "problem4b" ~: (assertEqual "problem4b" True (consistent problem4))
test4c = "problem4c" ~: (assertEqual "problem4c" (Just problem4) (LB.apply linStrategy problem3))
test4d = "problem4d" ~: (assertEqual "problem4d" True (similar problem0 problem4))
test4e = "problem4e" ~: (assertEqual "problem4e" False (isDone problem4))

Just problem5 = LB.apply moveConstant problem4
test5a = "problem5a" ~: (assertEqual "problem5a" "12x = 36\ny = 4" (pp2 problem5))
test5b = "problem5b" ~: (assertEqual "problem5b" True (consistent problem5))
test5c = "problem5c" ~: (assertEqual "problem5c" (Just problem5) (LB.apply linStrategy problem4))
test5d = "problem5d" ~: (assertEqual "problem5d" True (similar problem0 problem5))
test5e = "problem5e" ~: (assertEqual "problem5e" False (isDone problem5))

Just problem5buggy = LB.apply buggyConstants problem4
test5ab = "problem5ab" ~: (assertEqual "problem5ab" "12x = 52\ny = 4" (pp2 problem5buggy))
test5bb = "problem5bb" ~: (assertEqual "problem5bb" False (consistent problem5buggy))
test5db = "problem5db" ~: (assertEqual "problem5db" False (similar problem0 problem5buggy))
test5eb = "problem5eb" ~: (assertEqual "problem5eb" False (isDone problem5buggy))

Just problem6 = LB.apply computeX problem5
test6a = "problem6a" ~: (assertEqual "problem6a" "x = 3\ny = 4" (pp2 problem6))
test6b = "problem6b" ~: (assertEqual "problem6b" True (consistent problem6))
test6c = "problem6c" ~: (assertEqual "problem6c" (Just problem6) (LB.apply linStrategy problem5))
test6d = "problem6d" ~: (assertEqual "problem6d" True (similar problem0 problem6))
test6e = "problem6e" ~: (assertEqual "problem6e" True (isDone problem6))



linex2a = LE 6 1 0 22
linex2b = LE 4 2 0 20
oef1 = PR linex2a linex2b 3 4
der1 = printDerivations linExercise oef1


oef1_0 = PR (LE 6 1 0 22) (LE 4 2 0 20) 3 4
oef1_1 = PR (LE 12 2 0 44) (LE 4 2 0 20) 3 4
oef1_2 = PR (LE 12 2 0 44) (LE (-8) 0 0 (-24)) 3 4
oef1_3 = PR (LE 12 2 0 44) (LE 1 0 0 3) 3 4
oef1_4 = PR (LE 0 2 36 44) (LE 1 0 0 3) 3 4
oef1_5 = PR (LE 0 2 0 8) (LE 1 0 0 3) 3 4
oef1_5b = PR (LE 0 2 0 52) (LE 1 0 0 3) 3 4

oef1_6 = PR (LE 0 1 0 4) (LE 1 0 0 3) 3 4

oef1_20 = PR (LE 3 5 0 29) (LE 1 0 0 3) 3 4 :: IntPr

--Derivation #3
--PR (LE 6 1 0 22) (LE 4 2 0 20) 3 4

-- 1  => eval.y.factors.equal
--PR (LE 12 2 0 44) (LE 4 2 0 20) 3 4

-- 2  => eval.subtract.e1.from.e2
--PR (LE 12 2 0 44) (LE (-8) 0 0 (-24)) 3 4

-- 3 => eval.compute.x
--PR (LE 12 2 0 44) (LE 1 0 0 3) 3 4

-- 4  => eval.subtitute.x
--PR (LE 0 2 36 44) (LE 1 0 0 3) 3 4

-- 5  => eval.move.constant.right
--PR (LE 0 2 0 8) (LE 1 0 0 3) 3 4

-- 6  => eval.compute.y
--PR (LE 0 1 0 4) (LE 1 0 0 3) 3 4

s0 = startExercise oef1

pr1 = checkProgress s0 oef1_1
Just st1 = getState pr1

pr2 = checkProgress st1 oef1_2
--   => eval.y.factors.equal
Just st2 = getState pr2

Expected _ _ rule3 = pr2

pr3 = checkProgress st2 oef1_3
--   => eval.subtract.e1.from.e2
Just st3 = getState pr3

pr4 = checkProgress st3 oef1_4
Just st4 = getState pr4

pr5 = checkProgress st4 oef1_5
Just st5 = getState pr5

pr5b = checkProgress st4 oef1_5b
st5b = getState pr5b


pr6 = checkProgress st5 oef1_6
Just st6 = getState pr6



--Derivation #7
bugy1_0 = PR (LE 6 1 0 22) (LE 4 2 0 20) 3 4
--   => eval.y.factors.equal
bugy1_1 = PR (LE 12 2 0 44) (LE 4 2 0 20) 3 4
--   => eval.subtract.e2.from.e1
bugy1_2 = PR (LE 8 0 0 24) (LE 4 2 0 20) 3 4
--   => eval.compute.x
bugy1_3 = PR (LE 1 0 0 3) (LE 4 2 0 20) 3 4
--   => eval.substitute.x
bugy1_4 = PR (LE 1 0 0 3) (LE 0 2 12 20) 3 4
--   => buggy.move
bugy1_5 = PR (LE 1 0 0 3) (LE 0 2 0 32) 3 4
--   => eval.compute.y
bugy1_6 = PR (LE 1 0 0 3) (LE 0 1 0 16) 3 4

bu1 = checkProgress s0 bugy1_1
Just stbu1 = getState bu1

bu2 = checkProgress stbu1 bugy1_2
Just stbu2 = getState bu2

bu3 = checkProgress stbu2 bugy1_3
Just stbu3 = getState bu3

bu4 = checkProgress stbu3 bugy1_4
Just stbu4 = getState bu4

bu5 = checkProgress stbu4 bugy1_5
Just stbu5 = getState bu5

bu6 = checkProgress stbu5 bugy1_6
Just stbu6 = getState bu6




