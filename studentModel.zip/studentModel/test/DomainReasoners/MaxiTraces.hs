module DomainReasoners.MaxiTraces where

import DomainReasoners.MaxiDouble

import Ideas.Main.Default
import Ideas.Service.DomainReasoner
import Ideas.Common.Library
import qualified Ideas.Service.State as Ideas
import Ideas.Service.BasicServices as BS
import Ideas.Service.Diagnose
import Ideas.Main.Default






startExercise ::  MaxiExpr ->Ideas.State MaxiExpr
startExercise pr = Ideas.emptyState combinedExercise pr


checkProgress :: Ideas.State MaxiExpr -> MaxiExpr -> Diagnosis MaxiExpr
checkProgress state p = diagnose state (inContext combinedExercise p) Nothing

pd = printDerivation combinedExercise
pds = printDerivations combinedExercise

oef10 = Double (Const 3)
oef11 = Double oef10
oef20 = Maxi (Const 4) (Const 5)
oef30 = Maxi (Const 1) oef20
oef31 = Maxi oef10 (Const 7)
oef32 = Maxi oef10 oef20


