module DomainReasoners.MaxiTest where


import DomainReasoners.MaxiDouble

import Ideas.Common.Library
import Ideas.Main.Default
import Ideas.Service.DomainReasoner


import Test.HUnitPlus as UT


maxitest :: IO ()
maxitest = createMain [maxisuite]
maxisuite = (UT.testSuite "suite1" alltests){suiteConcurrently = False}
alltests =[tc1, ts2, ts3, ts4, ts5, ts6, ts7, ts8, ts9, tc10]

maxitest1 :: Test
maxitest1 = "test1" ~: (assertEqual "eq 2 3 " (length maxiEx) 3)

--testVersion = "version 1.5.1" ~: (assertEqual "version " "1.5.1 (c82b6d23d93eb1ed7d0fb046f1430a1fe87cddfd)" (version maxidr))

maxiEx :: [Some Exercise]
maxiEx = exercisesSorted maxidr

ts1="Maxi (Const 1) (Const 5)"
t1a = read ts1 ::MaxiExpr
term1 = toTerm t1a
Just t1b = fromTerm term1 :: Maybe MaxiExpr
tc1 = "term" ~: (assertEqual "tc1" t1a t1b)




ts2 = testit "ts2" "IF (GTR (Const 6) (Const 5)) (Const 6) (Const 5)"
ts3 = testit "ts3"  "Maxi (Plus (Const 3) (Const 3)) (IF (GTR (Const 1) (Const 5)) (Const 1) (Const 5))"
ts4 = testit "ts4"  "Maxi (Plus (Const 3) (Const 3)) (IF (BoolConst False) (Const 1) (Const 5))"
ts5 = testit "ts5"  "Maxi (Plus (Const 3) (Const 3)) (Const 5)"
ts6 = testit "ts6"  "Maxi (Const 6) (Const 5)"
ts7 = testit "ts7"  "IF (GTR (Const 6) (Const 5)) (Const 6) (Const 5)"
ts8 = testit "ts8"  "IF (BoolConst True) (Const 6) (Const 5)"
ts9 = testit "ts9"  "Const 6"

ts10 = "Frac (3 % 5)"
ts10a = read ts10 :: MaxiExpr
term10 = toTerm ts10a
Just t10b = fromTerm term10 :: Maybe MaxiExpr
tc10 = "term" ~: (assertEqual "tc10" ts10a t10b)


testit :: String -> String ->  Test
testit tn expr = "term" ~: (assertEqual tn ta tb) where
    ta = read expr :: MaxiExpr
    aterm = toTerm ta
    Just tb = fromTerm aterm :: Maybe MaxiExpr









