module Scenarios.Vocabulary where

import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps


-- task classes
cmpl_taskClass01        = PiBool    "COMPL.TC.01" -- completed task class 1
cmpl_taskClass02        = PiBool    "COMPL.TC.02"
cmpl_taskClass03        = PiBool    "COMPL.TC.03"
taskClass01             = mkSub     "TC.01"
taskClass02             = mkSub     "TC.02"
taskClass03             = mkSub     "TC.03"

-- learning tasks
learningTask04          = mkSub     "LT.04"
learningTask06          = mkSub     "LT.06"
learningTask14          = mkSub     "LT.14"
learningTask15          = mkSub     "LT.15"
learningTask19          = mkSub     "LT.19"
learningTask20          = mkSub     "LT.20"
cmpl_learningTask04     = PiBool    "COMPL.LT.04"
cmpl_learningTask06     = PiBool    "COMPL.LT.06"
cmpl_learningTask14     = PiBool    "COMPL.LT.14"
cmpl_learningTask19     = PiBool    "COMPL.LT.19"
cmpl_learningTask20     = PiBool    "COMPL.LT.20"

csDouble                = PiBool    "CS.double"
csMaxi                  = PiBool    "CS.maxi"
csCombined              = PiBool    "CS.combined"






hlpPlaceHolder          = PiBool    "HLP.placeholder"


-- rule executions
rlExprMaxi              = PiCount     "RL.expr.maxi" 1
rlExprDouble            = PiCount     "RL.expr.double" 1
rlExprGtr               = PiCount     "RL.expr.gtr" 1
rlExprIf                = PiCount     "RL.expr.if" 1
rlExprPlus              = PiCount     "RL.expr.plus" 1

-- domain concepts

dmFunctionApplication   = PiBloom     "DM.functionApplication"     -- domain concept function applicaion
dmListSyntax            = PiBloom     "SYN.listSyntax"             -- Haskell list syntax
dmExpressionEvaluation  = PiBloom     "CAUS.expressionEvaluation"  -- Mechanism of simple expression evaluation
dmLazyEvaluation        = PiBloom     "CAUS.lazy"                  -- lazy evaluation
dmStrictEvaluation      = PiBloom     "CAUS.strict"                -- strict evaluation

dmPlus                  = PiBloom     "PRE.plus"                   -- can use plus from the prelude
dmIf                    = PiBloom     "SYN.if"                     -- can use if expressions
dmGtr                   = PiBloom     "PRE.gtr"                    -- can use greater then









