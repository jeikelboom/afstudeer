module Scenarios.Curriculum where

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps


-- task classes
tc01ExprEva             = mkSub     "TC.01.ExpressionEvaluation"
tc02FirstSteps          = mkSub     "TC.02.FirstSteps"
tc03TypesClasses        = mkSub     "TC.03.TypesAndClasses"
cmpl_tc01               = PiBool    "CMPL.TC.01" -- completed task class 1
cmpl_tc02               = PiBool    "CMPL.TC.02"
cmpl_tc03               = PiBool    "CMPL.TC.03"

-- learning tasks
lt01double              = mkSub     "LT.01.double"
lt02double              = mkSub     "LT.02.double"
lt03double              = mkSub     "LT.03.double"
lt11maxi                = mkSub     "LT.11.maxi"
lt12maxi                = mkSub     "LT.12.maxi"
lt13maxi                = mkSub     "LT.13.maxi"
lt21combined            = mkSub     "LT21.combined"
lt22combined            = mkSub     "LT22.combined"
lt23combined            = mkSub     "LT23.combined"
cmpl_lt01               = PiBool    "CMPL.LT.01"
cmpl_lt02               = PiBool    "CMPL.LT.02"
cmpl_lt03               = PiBool    "CMPL.LT.03"
cmpl_lt11               = PiBool    "CMPL.LT.11"
cmpl_lt12               = PiBool    "CMPL.LT.12"
cmpl_lt13               = PiBool    "CMPL.LT.13"
cmpl_lt21               = PiBool    "CMPL.LT.21"
cmpl_lt22               = PiBool    "CMPL.LT.22"
cmpl_lt23               = PiBool    "CMPL.LT.23"

exDouble                = PiBool    "EX.double"
exMaxi                  = PiBool    "EX.maxi"
exCombined              = PiBool    "EX.combined"


pt01adding              = mkSub     "PT.01.addingFractions"



hlpPlaceHolder          = PiBool    "HLP.placeholder"


-- rule executions
rlExprDouble            = PiCount     "RL.expr.double" 1
rlExprPlus              = PiCount     "RL.expr.plus" 1
rlExprMaxi              = PiCount     "RL.expr.maxi" 1
rlExprGtr               = PiCount     "RL.expr.gtr" 1
rlExprIf                = PiCount     "RL.expr.if" 1
bgWrongPlus             = PiCount     "BUG.buggy.plus" 1
-- domain concepts

dmFunctionApplication   = PiBloom     "DM.functionApplication"     -- domain concept function applicaion
dmListSyntax            = PiBloom     "SYN.listSyntax"             -- Haskell list syntax
dmExpressionEvaluation  = PiBloom     "CAUS.expressionEvaluation"  -- Mechanism of simple expression evaluation
dmLazyEvaluation        = PiBloom     "CAUS.lazy"                  -- lazy evaluation
dmStrictEvaluation      = PiBloom     "CAUS.strict"                -- strict evaluation
dmPlus                  = PiBloom     "PRE.plus"                   -- can use plus from the prelude
dmIf                    = PiBloom     "SYN.if"                     -- can use if expressions
dmGtr                   = PiBloom     "PRE.gtr"                    -- can use greater then



modelPi = canonicalize $
    esModel
    `with` (tc01ExprEva
        `with` esIsTaskClass
        `with` (esSuccessCriteria
            `with` exDouble
            `with` exMaxi
            `with` exCombined
        )
        `with` (esObjective
            `with` cmpl_tc01
        )

        -- Learning task 01..03 double  (double (double 4 ))
        `with` (lt01double
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
            )
            `with` (esObjective
                `with` exDouble
                `with` dmPlus Comprehension
            )
        )
        `with` (lt02double
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
            )
            `with` (esObjective
                `with` exDouble
                `with` dmPlus Comprehension
            )
        )
        `with` (lt03double
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
            )
            `with` (esObjective
                `with` exDouble
                `with` dmPlus Comprehension
            )
        )

        -- Learning task 11 maxi (maxi 5 3 )
        `with` (lt11maxi
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` exDouble
             )
            `with` (esObjective
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exMaxi
            )
        )
        `with` (lt12maxi
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` exDouble
             )
            `with` (esObjective
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exMaxi
            )
        )
        `with` (lt13maxi
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` exDouble
             )
            `with` (esObjective
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exMaxi
            )
        )

        -- learning task 21 combined (maxi 11 (double 7 ))
        `with` (lt21combined
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` exMaxi
             )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmPlus Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exCombined
            )
        )
        `with` (lt22combined
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` exMaxi
             )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmPlus Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exCombined
            )
        )
        `with` (lt23combined
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` exMaxi
             )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmPlus Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exCombined
            )
        )
        `with` (pt01adding
            `with` esIsPartTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esPrerequisite
                `with` bgWrongPlus
             )
            `with` (esObjective
                `with` bgWrongPlus
                `with` dmExpressionEvaluation Comprehension
                `with` dmPlus Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` exCombined
            )
        )
    )
    `with` (tc02FirstSteps
        `with` esIsTaskClass
        `with` (esPrerequisite
            `with` dmExpressionEvaluation Comprehension
            `with` cmpl_tc01
        )
        `with` (esObjective
            `with` dmFunctionApplication Comprehension
        )
     )
    `with` (tc03TypesClasses `with` hlpPlaceHolder
        `with` esIsTaskClass
        `with` (esPrerequisite
            `with` cmpl_tc02
        )
    )



lt01ruleExecution a = esModel `plus` tc01ExprEva `plus` lt01double `plus` drRules `plus` a
lt02ruleExecution a = esModel `plus` tc01ExprEva `plus` lt02double `plus` drRules `plus` a
lt02Buggy a = esModel `plus` tc01ExprEva `plus` lt02double `plus` drBuggy `plus` a

lt11ruleExecution a = esModel `plus` tc01ExprEva `plus` lt11maxi `plus` drRules `plus` a
lt12ruleExecution a = esModel `plus` tc01ExprEva `plus` lt12maxi `plus` drRules `plus` a
lt21ruleExecution a = esModel `plus` tc01ExprEva `plus` lt21combined `plus` drRules `plus` a
lt22ruleExecution a = esModel `plus` tc01ExprEva `plus` lt22combined `plus` drRules `plus` a
lt23ruleExecution a = esModel `plus` tc01ExprEva `plus` lt23combined `plus` drRules `plus` a
lt01state a = esModel `plus` tc01ExprEva `plus` lt01double `plus` a
lt02state a = esModel `plus` tc01ExprEva `plus` lt02double `plus` a
lt11state a = esModel `plus` tc01ExprEva `plus` lt11maxi `plus` a
lt12state a = esModel `plus` tc01ExprEva `plus` lt12maxi `plus` a
lt21state a = esModel `plus` tc01ExprEva `plus` lt21combined `plus` a
lt22state a = esModel `plus` tc01ExprEva `plus` lt22combined `plus` a
lt23state a = esModel `plus` tc01ExprEva `plus` lt23combined `plus` a
