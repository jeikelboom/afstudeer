module Scenarios.ScenarioExprEval where

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.Vocabulary


modelPi = canonicalize $
    esModel
    `with` (esStudent
        `with` hlpPlaceHolder )
    `with` (taskClass01
        `with` esIsTaskClass
        `with` (esSuccessCriteria
            `with` csCombined
            `with` csMaxi
            `with` csDouble
        )
        `with` (esObjective
            `with` cmpl_taskClass01
        )

        -- learning task 04 (maxi 11 (double 7 ))
        `with` (learningTask04
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprDouble
                `with` rlExprGtr
                `with` rlExprIf
                `with` rlExprPlus
            )
            `with` (esPrerequisite
                `with` csMaxi
                `with` csDouble
             )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` dmPlus Comprehension
                `with` csCombined
            )
        )
        -- Learning task 06 combined (double (maxi 5 3 ))
        `with` (learningTask06
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprDouble
                `with` rlExprGtr
                `with` rlExprIf
                `with` rlExprPlus
            )
            `with` (esPrerequisite
                `with` csMaxi
                `with` csDouble
             )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` dmPlus Comprehension
                `with` csCombined
            )
        )
        -- Learning task 14 double  (double (double 4 ))
        `with` (learningTask14
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
            )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` csDouble
            )
        )
        -- Learning task 15 double  (double (double 5 ))
        `with` (learningTask15
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprDouble
                `with` rlExprPlus
            )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` csDouble
            )
        )
        -- Learning task 19 maxi (maxi 5 3 )
        `with` (learningTask19
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` csMaxi
            )
        )
        -- Learning task 20 maxi (maxi 2 8 )
        `with` (learningTask20
            `with` esIsLearningTask
            `with` (esSuccessCriteria
                `with` rlExprMaxi
                `with` rlExprGtr
                `with` rlExprIf
            )
            `with` (esObjective
                `with` dmExpressionEvaluation Comprehension
                `with` dmIf Comprehension
                `with` dmGtr Comprehension
                `with` csMaxi
            )
        )
    )
    `with` (taskClass02
        `with` esIsTaskClass
        `with` (esPrerequisite
            `with` dmExpressionEvaluation Comprehension
            `with` cmpl_taskClass01
        )
        `with` (esObjective
            `with` dmFunctionApplication Comprehension
        )
     )
    `with` (taskClass03 `with` hlpPlaceHolder
        `with` esIsTaskClass
        `with` (esPrerequisite
            `with` cmpl_taskClass02
        )
    )



lt04ruleExecution a = esModel `plus` taskClass01 `plus` learningTask04 `plus` drRules `plus` a
lt06ruleExecution a = esModel `plus` taskClass01 `plus` learningTask06 `plus` drRules `plus` a
lt14ruleExecution a = esModel `plus` taskClass01 `plus` learningTask14 `plus` drRules `plus` a
lt19ruleExecution a = esModel `plus` taskClass01 `plus` learningTask19 `plus` drRules `plus` a
lt20ruleExecution a = esModel `plus` taskClass01 `plus` learningTask20 `plus` drRules `plus` a
lt04state a = esModel `plus` taskClass01 `plus` learningTask04 `plus` a
lt06state a = esModel `plus` taskClass01 `plus` learningTask06 `plus` a
lt14state a = esModel `plus` taskClass01 `plus` learningTask14 `plus` a
lt19state a = esModel `plus` taskClass01 `plus` learningTask19 `plus` a
lt20state a = esModel `plus` taskClass01 `plus` learningTask20 `plus` a


step0 =  lt14state          drCreated
step1 =  lt14ruleExecution   rlExprDouble
step2 =  lt14ruleExecution   rlExprDouble
step3 =  lt14ruleExecution   rlExprDouble
step4 =  lt14ruleExecution   rlExprPlus
step5 =  lt14ruleExecution   rlExprPlus
step6 =  lt14ruleExecution  rlExprPlus      \/
         lt14state          esFinished
--
step7 =  lt19state          drCreated
step8 =  lt19ruleExecution  rlExprMaxi      \/
         lt19state          esFinished
--
--
step9 =   lt20state         drCreated
step10 =  lt20ruleExecution  rlExprMaxi
step11 =  lt20ruleExecution  rlExprGtr
step12 =  lt20ruleExecution  rlExprIf      \/
          lt20state         esFinished
--
step14 =  lt04state         drCreated
step15 =  lt04state         ( mkSub "step15" `plus` esError) \/
          lt04ruleExecution esError
step16 =  lt04ruleExecution  rlExprDouble
step17 =  lt04ruleExecution  rlExprPlus
step18 =  lt04ruleExecution  rlExprMaxi
step19 =  lt04state         ( mkSub "step19" `plus` esError) \/
          lt04ruleExecution esError
step20 =  lt04ruleExecution  rlExprGtr
step21 =  lt04ruleExecution rlExprIf      \/
          lt04state         esFinished
--
step22 =  lt06state         drCreated
step23 =  lt06ruleExecution  rlExprDouble
step24 =  lt06ruleExecution  rlExprMaxi
step25 =  lt06ruleExecution  rlExprGtr
step26 =  lt06ruleExecution  rlExprIf
step27 =  lt06ruleExecution  rlExprMaxi
step28 =  lt06ruleExecution  rlExprGtr
step29 =  lt06ruleExecution  rlExprIf
step30 =  lt06ruleExecution  rlExprPlus       \/
          lt06state         esFinished
--
exlearningTask14 = [step0, step1, step2, step3, step4, step5, step6]
exlearningTask19 = [step7, step8]
exlearningTask20 = [step9, step10, step11, step12]
exlearningTask04 = [step14, step15, step16, step17, step18, step19, step20, step21]
exlearningTask06 = [step22, step23, step24, step25, step26, step27, step28, step29, step30]
--
---- trace normale student:
tracePi = exlearningTask14 ++ exlearningTask19 ++ exlearningTask20 ++ exlearningTask04 ++ exlearningTask06

trace = map (\s -> Step{step=s}) tracePi
scenario = Model{model = modelPi}



learningCurve :: [Model]
learningCurve = scanl (stepProcessor rp2) scenario trace

learningCurveId :: [Model]
learningCurveId = scanl (stepProcessor id) scenario trace


--errors = map rp learningCurve






