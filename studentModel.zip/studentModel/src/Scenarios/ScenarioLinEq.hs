module Scenarios.ScenarioLinEq where

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps



taskClass01             = mkTaskClass     "TC.Simple lineair equations"
cmpl_taskClass01        = PiBool    "COMPL.TC.Simple lineair equations" -- completed task class 1

learningTask01          = mkLearningTask     "LT.exercise1"
learningTask02          = mkLearningTask     "LT.exercise2"

partTask01              = mkPartTask         "PT.practice1"
partTask02              = mkPartTask         "PT.practice2"

scExercisesCompleted    = PiCount   "SC.exercisesSuccessfullCompleted"

rlMakeFactorsEqual      = PiCount   "RL.makeFactorsEqual" 1
rlSubtractExpression    = PiCount   "RL.subtractEpressions" 1
rlComputeVariable       = PiCount   "RL.computeVariable" 1
rlSubstitution          = PiCount   "RL.substitution" 1
rlMoveConstant          = PiCount   "RL.moveConstant" 1
bgWrongMove             = PiCount   "BUG.wrongMove"

dmLCM                   = PiBloom   "MATH.leastCommonMultiple"
dmGCD                   = PiBloom   "MATH.greatestCommonDivisor"
dmEquivalence           = PiBloom   "MATH.expressionEquivalence"
dmSubstitution          = PiBloom   "MATH.variableSubstitution"
dmIntLineairEquations   = PiBloom   "MATH.integerLineairEquations"


-- A homogeneous task class where exercises have similar attributes.

-- generic success criteria
leSuccessCriteria = esSuccessCriteria
            `with` rlMakeFactorsEqual
            `with` rlSubtractExpression
            `with` rlComputeVariable
            `with` rlSubstitution
            `with` rlMoveConstant
-- Failure criteria
leFailureCritera = esFailureCriteria
            `with` bgWrongMove 1
-- generic prerequisites
lePrerequisites = esPrerequisite
            `with` dmLCM Comprehension
            `with` dmGCD Comprehension
ptPrerequisites  n = esPrerequisite
            `with` bgWrongMove n
-- generic exercise objectives
leObjectives = esObjective
            `with` dmLCM Application
            `with` dmGCD Application
            `with` dmEquivalence Application
            `with` dmSubstitution Application
            `with` dmIntLineairEquations Comprehension
            `with` scExercisesCompleted 1
-- generic learning task
leLearningTask ltask = ltask
            `with` leSuccessCriteria
            `with` leFailureCritera
            `with` lePrerequisites
            `with` leObjectives
lePartTask ptask = ptask
            `with` ptPrerequisites 1



linEqCurriculum = canonicalize $
    esModel
    `with` (esStudent
        `with` dmLCM Comprehension
        `with` dmGCD Comprehension)
    `with` (taskClass01
        `with` (esSuccessCriteria
           `with` scExercisesCompleted 5
        )
        `with` (esObjective
           `with` cmpl_taskClass01

        )
        `with` leLearningTask learningTask01
        `with` leLearningTask learningTask02
        `with` (partTask01
            `with` (esPrerequisite
                `with` bgWrongMove 1
            )
            `with` (esObjective
                `with` bgWrongMove 1
            )
        )
        `with` (partTask02
            `with` (esPrerequisite
                `with` bgWrongMove 1
            )
            `with` (esObjective
                `with` bgWrongMove 1
            )
        )
     )


{-

Derivation #3
6x + y = 22
4x + 2y = 20
   => eval.x.factors.equal
12x + 2y = 44
12x + 6y = 60
   => eval.subtract.e2.from.e1
- 4y = -16
12x + 6y = 60
   => eval.compute.y
y = 4
12x + 6y = 60
   => eval.substitute.y
y = 4
12x + 24 = 60
   => buggy.move
y = 4
12x = 84
   => eval.compute.x
y = 4
x = 7

-}


lt01Expected a = esModel `plus` taskClass01 `plus` learningTask01 `plus` drExpected `plus` a
lt01Buggy a = esModel `plus` taskClass01 `plus` learningTask01 `plus` drBuggy `plus` a
lt01state a =         esModel `plus` taskClass01 `plus` learningTask01 `plus` a
lt01Finished a = lt01Expected  a   \/ lt01state esFinished

happy0 =  lt01state     drCreated
happy1 =  lt01Expected   rlMakeFactorsEqual
happy2 =  lt01Expected   rlSubtractExpression
happy3 =  lt01Expected   rlComputeVariable
happy4 =  lt01Expected   rlSubstitution
happy5 =  lt01Expected   rlMoveConstant
happy6 =  lt01Finished rlComputeVariable

happyTask01 = [happy0, happy1, happy2, happy3, happy4, happy5, happy6]

happyTrace = map (\s -> Step{step=s}) happyTask01
curriculum = Model{model = linEqCurriculum}

learningCurveLinEq :: [Model]
learningCurveLinEq = scanl (stepProcessor rp2) curriculum happyTrace


{-
Derivation #7
6x + y = 22
4x + 2y = 20
   => eval.y.factors.equal
12x + 2y = 44
4x + 2y = 20
   => eval.subtract.e2.from.e1
8x = 24
4x + 2y = 20
   => eval.compute.x
x = 3
4x + 2y = 20
   => eval.substitute.x
x = 3
2y + 12 = 20
   => buggy.move
x = 3
2y = 32
   => eval.compute.y
x = 3
y = 16


Derivation #7
PR (LE 6 1 0 22) (LE 4 2 0 20) 3 4
   => eval.y.factors.equal
PR (LE 12 2 0 44) (LE 4 2 0 20) 3 4
   => eval.subtract.e2.from.e1
PR (LE 8 0 0 24) (LE 4 2 0 20) 3 4
   => eval.compute.x
PR (LE 1 0 0 3) (LE 4 2 0 20) 3 4
   => eval.substitute.x
PR (LE 1 0 0 3) (LE 0 2 12 20) 3 4
   => buggy.move
PR (LE 1 0 0 3) (LE 0 2 0 32) 3 4
   => eval.compute.y
PR (LE 1 0 0 3) (LE 0 1 0 16) 3 4

-}

buggy0 = lt01state          drCreated
buggy1 = lt01Expected   rlMakeFactorsEqual
buggy2 = lt01Expected   rlSubtractExpression
buggy3 = lt01Expected   rlComputeVariable
buggy4 = lt01Expected   rlSubstitution
buggy5 = lt01Buggy  $ bgWrongMove 1
buggy6 = lt01Expected   rlMoveConstant
buggy7 = lt01Finished rlComputeVariable


buggyTask01 = [buggy0, buggy1, buggy2, buggy3, buggy4, buggy5, buggy6, buggy7]
buggyTrace = map (\s -> Step{step=s}) buggyTask01

buggyLearningCurveLinEq :: [Model]
buggyLearningCurveLinEq = scanl (stepProcessor rp2) curriculum buggyTrace






