module Scenarios.FastStudent where

import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import Scenarios.Curriculum



-- lt01
step010 =  lt01state          drCreated
step011 =  lt01ruleExecution   rlExprDouble
step012 =  lt01ruleExecution   rlExprDouble
step013 =  lt01ruleExecution   rlExprDouble
step014 =  lt01ruleExecution   rlExprPlus
step015 =  lt01ruleExecution   rlExprPlus
step016 =  lt01ruleExecution   rlExprPlus       \/
         lt01state          esFinished
-- lt11 exercise maxi took shortcut
step117 =  lt11state          drCreated
step118 =  lt11ruleExecution   rlExprMaxi      \/
         lt11state          esFinished
--
-- lt12
step129 =   lt12state         drCreated
step1210 =  lt12ruleExecution  rlExprMaxi
step1211 =  lt12ruleExecution  rlExprGtr
step1212 =  lt12ruleExecution  rlExprIf     \/
          lt12state         esFinished
-- lt21
step2114 =  lt21state         drCreated
step2115 =  lt21state         ( mkSub "step2115" `plus` esError) \/
          lt21ruleExecution esError
step2116 =  lt21ruleExecution  rlExprDouble
step2117 =  lt21ruleExecution  rlExprPlus
step2118 =  lt21ruleExecution  rlExprMaxi
step2119 =  lt21state         ( mkSub "step2119" `plus` esError) \/
          lt21ruleExecution esError
step2120 =  lt21ruleExecution  rlExprGtr
step2121 =  lt21ruleExecution  rlExprIf      \/
          lt21state         esFinished


-- lt22
step2222 =  lt22state         drCreated
step2223 =  lt22ruleExecution  rlExprDouble
step2224 =  lt22ruleExecution  rlExprMaxi
step2225 =  lt22ruleExecution  rlExprGtr
step2226 =  lt22ruleExecution  rlExprIf
step2227 =  lt22ruleExecution  rlExprMaxi
step2228 =  lt22ruleExecution  rlExprGtr
step2229 =  lt22ruleExecution  rlExprIf
step2230 =  lt22ruleExecution  rlExprPlus       \/
          lt22state         esFinished
--


exlearningTask01 = [step010, step011, step012, step013, step014, step015, step016]
exlearningTask11 = [step117, step118]
exlearningTask12 = [step129, step1210, step1211, step1212]
exlearningTask21 = [step2114, step2115, step2116, step2117, step2118, step2119, step2120, step2121]
exlearningTask22 = [step2222, step2223, step2224, step2225, step2226, step2227, step2228, step2229, step2230]
--
---- trace normale student:
startModel = Model{model = modelPi}

traceNormalStudentPI = exlearningTask01 ++ exlearningTask12 ++ exlearningTask22
traceNormalStudent = map (\s -> Step{step=s}) traceNormalStudentPI
learningCurveNormalStudent :: [Model]
learningCurveNormalStudent = scanl (stepProcessor rp2) startModel traceNormalStudent


traceSlowStudentPI = exlearningTask01 ++ exlearningTask11 ++ exlearningTask12 ++ exlearningTask21 ++ exlearningTask22
traceSlowStudent = map (\s -> Step{step=s}) traceSlowStudentPI
learningCurveSlowStudent :: [Model]
learningCurveSlowStudent = scanl (stepProcessor rp2) startModel traceSlowStudent


traceFastStudentPI = exlearningTask22
traceFastStudent = map (\s -> Step{step=s}) traceFastStudentPI
learningCurveFastStudent :: [Model]
learningCurveFastStudent = scanl (stepProcessor rp3) startModel traceFastStudent


{-
Derivation #14
 double ( double  3 % 4 )
   => expr.double
( double  3 % 4 ) + ( double  3 % 4 )
   => expr.double
( 3 % 4  +  3 % 4 ) + ( double  3 % 4 )
   => expr.double
( 3 % 4  +  3 % 4 ) + ( 3 % 4  +  3 % 4 )
   => expr.plus
 3 % 2  + ( 3 % 4  +  3 % 4 )
   => buggy.plus
 3 % 2  +  3 % 4
   => expr.plus
 9 % 4

-}


-- lt02 buggy
step020 =  lt02state          drCreated
step021 =  lt02ruleExecution   rlExprDouble
step022 =  lt02ruleExecution   rlExprDouble
step023 =  lt02ruleExecution   rlExprDouble
step024 =  lt02ruleExecution   rlExprPlus
step025 =  lt02Buggy   bgWrongPlus  \/ lt02state         esFinished
step026 =  lt02ruleExecution   rlExprPlus  \/    lt02state         esFinished

exlearningTask20 = [step020, step021, step022, step023, step024, step025]


traceBuggytudentPI = exlearningTask20
traceBuggyStudent = map (\s -> Step{step=s}) traceBuggytudentPI
learningCurveBuggyStudent :: [Model]
learningCurveBuggyStudent = scanl (stepProcessor rp3) startModel traceBuggyStudent

