
{-# LANGUAGE DeriveDataTypeable #-}
module DomainReasoners.LineairEquations where



import Ideas.Common.Library
import qualified Ideas.Service.State as Ideas
import Ideas.Service.BasicServices as BS
import Ideas.Service.Diagnose
import Ideas.Main.Default
import Data.Ratio
import Data.Typeable
import Data.Data

import Text.PrettyPrint as PR

-- a * x + b * y + c = d

data LinEq t = LE t t t t
    deriving (Eq, Show, Read, Typeable, Data)

instance Functor LinEq  where
    fmap f (LE a b c d)= LE (f a) (f b) (f c) (f d)

instance Applicative LinEq   where
    pure f = LE f f f f
    (LE a1 b1 c1 d1) <*> (LE a2 b2 c2 d2) = LE (a1 a2) (b1 b2) (c1 c2) (d1 d2)

-- a1 * x + b1 * y + c1 = d1
-- a2 * x + b2 * y + c2 = d2
-- x an y (solution)
data Problem t  = PR  (LinEq t) (LinEq t) t t
    deriving (Eq, Show, Read, Typeable, Data)

type IntEq = LinEq Int
type IntPr = Problem Int

xx,yy :: Problem t -> t
xx (PR _ _ a _) = a
yy (PR _ _ _ a) = a


consistentEq :: (Num t, Eq t) => LinEq t -> t -> t -> Bool
consistentEq (LE a b c d) x y = a * x + b * y + c == d

consistent :: (Num t, Eq t) => Problem t -> Bool
consistent (PR e1 e2 x y) = consistentEq e1 x y && consistentEq e2 x y

times :: (Num t, Eq t) => t -> LinEq t -> LinEq t
times r  le = pure (r *) <*> le

minus :: (Num t, Eq t) => LinEq t -> LinEq t -> LinEq t
minus le1 le2 = pure (-) <*> le1 <*> le2

divide :: (Integral t, Eq t) => t -> LinEq t -> LinEq t
divide dd le = pure (`div` dd) <*> le



canformX :: Rule IntPr
canformX = describe "Make coefficients of X equal" $ makeRule "eval.X.factors.Equal" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            | a1 == 0 = Nothing
            | b1 == 0 = Nothing
            | a2 == 0 = Nothing
            | b2 == 0 = Nothing
            | a1 == a2 = Nothing
            | b1 == b2 = Nothing
            | otherwise = Just (PR (f1 `times` e1) (f2 `times` e2) x y)
                  where
                    l = lcm a1 a2
                    f1 = l `div` a1
                    f2 = l `div` a2

canformY :: Rule IntPr
canformY = describe "Make coefficients of Y equal" $ makeRule "eval.Y.factors.Equal" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            | a1 == 0 = Nothing
            | b1 == 0 = Nothing
            | a2 == 0 = Nothing
            | b2 == 0 = Nothing
            | a1 == a2 = Nothing
            | b1 == b2 = Nothing
            | otherwise = Just (PR (f1 `times` e1) (f2 `times` e2) x y)
                  where
                    l = lcm b1 b2
                    f1 = l `div` b1
                    f2 = l `div` b2

eliminateXY1 :: Rule IntPr
eliminateXY1 = describe "Subtract first from second equation" $ makeRule "eval.subtract.E1.from.E2" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            | a1 == a2 = Just (PR e1 (e2 `minus` e1) x y)
            | b1 == b2 = Just (PR e1 (e2 `minus` e1) x y)
            | otherwise = Nothing

eliminateXY2 :: Rule IntPr
eliminateXY2 = describe "Subtract second from first equation" $ makeRule "eval.subtract.E2.from.E1" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            | a1 == a2 = Just (PR (e1 `minus` e2) e2 x y)
            | b1 == b2 = Just (PR (e1 `minus` e2) e2 x y)
            | otherwise = Nothing

computeX :: Rule IntPr
computeX = describe "compute X" $ makeRule "eval.compute.X" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            -- compute x in eq1
           |a1/=0 && a1/=1 && b1==0 && c1==0 = Just (PR (LE 1 0 0 (d1 `div` a1)) e2 x y)
            -- compute x in eq2
           |a2/=0 && a2/=1 && b2==0 && c2==0 = Just (PR e1 (LE 1 0 0 (d2 `div` a2)) x y)
           | otherwise = Nothing
            where
                v1=d1-c1
                v2=d2-c2

computeY :: Rule IntPr
computeY = describe "compute Y" $ makeRule "eval.compute.Y" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            -- compute y in eq1
           |a1==0 && b1/=0 && b1/=1 && c1==0 = Just (PR (LE 0 1 0 (d1 `div` b1)) e2 x y)
            -- compute y in eq2
           |a2==0 && b2/=0 && b2/=1 && c2==0 = Just (PR e1 (LE 0 1 0 (d2 `div` b2)) x y)
           | otherwise = Nothing
            where
                v1=d1-c1
                v2=d2-c2



substituteX :: Rule IntPr
substituteX = describe "substitute X" $ makeRule "eval.substitute.X" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            -- substitute x from eq 1 x = d1
            | a1 == 1 && b1 == 0 && c2 == 0 && a2 /= 0  = Just (PR e1 (LE 0  b2 (a2 * d1) d2)    x y)
            -- substitute x from eq 2 x = d2-c2
            | a2 == 1 && b2 == 0 && c1 == 0 && a1 /= 0   = Just (PR    (LE 0  b1 (a1 * d2) d1) e2 x y)
            | otherwise = Nothing

substituteY :: Rule IntPr
substituteY = describe "substitute Y" $ makeRule "eval.substitute.Y" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            -- substitute Y from eq 1 y = d1-c1
            | a1 == 0 && b1 == 1 && c2 == 0 && b2 /= 0  = Just (PR e1 (LE a2 0  (b2 * d1) d2)    x y)
            -- substitute Y from eq 2: y2 = d2-c2
            | a2 == 0 && b2 == 1 && c1 == 0 && b1 /= 0   = Just (PR    (LE a1 0  (b1 * d2) d1) e2 x y)
            | otherwise = Nothing

moveConstant :: Rule IntPr
moveConstant = describe "move constant" $ makeRule "eval.move.constant.right" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            | c1 /= 0 = Just  (PR (LE a1 b1 0 (d1 -c1)) e2 x y)
            | c2 /= 0 = Just  (PR e1 (LE a2 b2 0 (d2 -c2))  x y)
            | otherwise = Nothing

buggyConstants :: Rule IntPr
buggyConstants = describe "wrong move constant" $ buggyRule "buggy.move" f
    where
        f :: IntPr -> Maybe IntPr
        f (PR e1@(LE a1 b1 c1 d1) e2@(LE a2 b2 c2 d2)  x y)
            | c1 /= 0 = Just  (PR (LE a1 b1 0 (d1 + c1)) e2 x y)
            | c2 /= 0 = Just  (PR e1 (LE a2 b2 0 (d2 + c2))  x y)
            | otherwise = Nothing

-- Pretty printer
ppProblem :: IntPr -> Doc
ppProblem (PR eq1 eq2 _ _) = ppIntEq eq1 PR.$$ ppIntEq eq2

ppIntEq :: IntEq -> Doc
ppIntEq expr = printa expr PR.<+> printPlus expr PR.<+> printb expr PR.<+> printc expr PR.<+> printd expr

printa :: IntEq ->  Doc
printa (LE a b c d) | a == 0 = PR.empty
                    | a == 1 = text "x"
                    | otherwise = PR.int a PR.<> text "x"

printPlus :: IntEq ->  Doc
printPlus (LE a b c d)  | a == 0 && b >= 0  = PR.empty
                        | b == 0            = PR.empty
                        | b < 0             = PR.text "-"
                        | otherwise         = PR.text "+"

printb :: IntEq ->  Doc
printb eq1@(LE a b c d) | b == 0 = PR.empty
                        | b == 1 =                   text "y"
                        | b > 0 =  PR.int b    PR.<> text "y"
                        | b < 0 =  PR.int (-b) PR.<> text "y"

printc :: IntEq -> Doc
printc (LE a b c d) | c == 0 = PR.empty
                    | c < 0 = text "-" PR.<+> PR.int (-c)
                    | c > 0 = text "+" PR.<+> PR.int c

printd :: IntEq -> Doc
printd (LE a b c d) = text "=" PR.<+> PR.int d

pp1 p = putStrLn $ render $ ppProblem p
pp2 p = render $ ppProblem p

linStrategy :: LabeledStrategy IntPr
linStrategy = label "Simple strategy for lin eqn" $
    canformX .|. canformY .|. eliminateXY1  .|. eliminateXY2  .|. substituteX  .|. substituteY .|. moveConstant  .|. computeX .|. computeY .|. buggyConstants

linExercise :: Exercise IntPr
linExercise = emptyExercise
    { exerciseId = describe "Solve lineair equations" $ newId "eval.minimum"
    , strategy = liftToContext solutionStrategy
    , prettyPrinter = pp2
    , similarity = (==)
    , equivalence  = withoutContext equiv
    , ready = predicate  isDone
    }
--
solutionStrategy :: LabeledStrategy IntPr
solutionStrategy = label "solution" $
   while (not . isDone)  linStrategy
--
similar :: IntPr -> IntPr -> Bool
similar a b = consistent a && consistent b && xx a == xx b && yy a == yy b
equiv  = similar
--
isDone :: IntPr -> Bool
isDone (PR (LE a1 b1 c1 d1) (LE a2 b2 c2 d2) _ _) =
    (a1==1 && b1==0 && c1==0 && a2==0 && b2==1 && c2==0) ||
    (a1==0 && b1==1 && c1==0 && a2==1 && b2==0 && c2==0)
--
--
--

startExercise ::  IntPr ->Ideas.State IntPr
startExercise  = Ideas.emptyState linExercise


checkProgress :: Ideas.State IntPr -> IntPr -> Diagnosis IntPr
checkProgress state p = diagnose state (inContext linExercise p) Nothing














