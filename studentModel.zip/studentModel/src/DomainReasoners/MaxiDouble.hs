{-
Exercise 2

maxi x y = if (x > y) then x else y

-}
{-#LANGUAGE GADTs #-}
module DomainReasoners.MaxiDouble  where

import Ideas.Common.Library
import Ideas.Main.Default
import Data.Ratio


data MaxiExpr = Maxi MaxiExpr MaxiExpr
              | Double MaxiExpr
              | Plus MaxiExpr MaxiExpr
              | IF MaxiExpr MaxiExpr MaxiExpr
              | GTR MaxiExpr MaxiExpr
              | LEQ MaxiExpr MaxiExpr
              | Frac  Rational
              | Const Integer
              | BoolConst Bool
              deriving (Eq, Show, Read)

fr :: Integer -> MaxiExpr
fr n = Frac (n % 1)
fr2 :: Integer -> Integer -> MaxiExpr
fr2 t n = Frac (t % n)

buggyAdd :: Rational -> Rational -> Rational
buggyAdd a b = (numerator a + numerator b) % (denominator a + denominator b)

eval :: MaxiExpr -> MaxiExpr

eval (Maxi x y) = eval (IF (LEQ x y) y x)
eval (IF (BoolConst c) x y) = eval (if c then x else y)
eval (IF c x y) = eval (IF (evalb c) x y)
eval (Double a ) = eval (Plus a a)
eval (Plus (Const a) (Const b)) = Const (a + b)
eval (Plus (Frac a) (Frac b)) = Frac (a + b)
eval (Plus a b) = eval (Plus (eval a)  (eval b))
eval x = x

evalb :: MaxiExpr ->  MaxiExpr
evalb (GTR (Const a) (Const b)) = BoolConst ( a > b)
evalb (GTR (Frac a) (Frac b)) = BoolConst ( a > b)
evalb (GTR a b) = eval (GTR (eval a) (eval b))
evalb (LEQ (Const a) (Const b)) = BoolConst ( a <= b)
evalb (LEQ (Frac a) (Frac b)) = BoolConst ( a <= b)
evalb (LEQ a b) = eval (LEQ (eval a) (eval b))


prettyMaxi :: String -> String
prettyMaxi  = pp . read

pp, ppb :: MaxiExpr -> String
pp (Maxi e1 e2) = "maxi " ++ ppb e1 ++ " "  ++ ppb e2
pp (Double e1) = " double " ++ ppb e1
pp (Plus e1 e2) =  ppb e1 ++ " + " ++ ppb e2
pp (IF e1 e2 e3) = "if " ++ ppb e1 ++ " then " ++ ppb e2 ++ " else " ++ ppb e3
pp (GTR e1 e2) = ppb e1 ++ " > " ++ ppb e2
pp (LEQ e1 e2) = ppb e1 ++ " <= " ++ ppb e2
pp (Const e1) = " " ++ show e1 ++ " "
pp (Frac e1) = " " ++ show e1 ++ " "
pp (BoolConst e1) = " " ++ show e1 ++ " "


ppb (Const e1) = " " ++ show e1 ++ " "
ppb (Frac e1) = " " ++ show e1 ++ " "
ppb (BoolConst e1) = " " ++ show e1 ++ " "
ppb a = "(" ++ pp a ++ ")"



maxiRule :: Rule MaxiExpr
maxiRule = describe "Applying maxi" $ makeRule "expr.maxi" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
--        f (Maxi (Const x) (Const y)) = Just $ IF (GTR (Const x) (Const y)) (Const x) (Const y)
        f (Maxi x y) = Just $ IF (LEQ x y)  y x
        f _ = Nothing


doubleRule :: Rule MaxiExpr
doubleRule = describe "Applying double" $ makeRule "expr.double" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
        f (Double a) = Just $ Plus a a
        f _ = Nothing


plusRule :: Rule MaxiExpr
plusRule = describe "Apply +" $ makeRule "expr.plus" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
        f (Plus (Const a) (Const b)) = Just $ Const (a + b)
        f (Plus (Frac a) (Frac b)) = Just $ Frac (a + b)
        f _ = Nothing

buggyPlusRule :: Rule MaxiExpr
buggyPlusRule = describe "error adding rationals" $ buggyRule "buggy.plus" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
        f (Plus (Frac a) (Frac b)) = Just $ Frac (buggyAdd a b)
        f _ = Nothing




ifRule :: Rule MaxiExpr
ifRule = describe "Apply if" $ makeRule "expr.if" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
        f (IF (BoolConst c) x y) = Just $ if c then x else y
        f _ = Nothing

gtrRule :: Rule MaxiExpr
gtrRule = describe "Apply >" $ makeRule "expr.gtr" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
        f (GTR (Const x) (Const y)) = Just $ BoolConst (x > y)
        f (GTR (Frac x) (Frac y)) = Just $ BoolConst (x > y)
        f _ = Nothing

leqRule :: Rule MaxiExpr
leqRule = describe "Apply <=" $ makeRule "expr.leq" f
    where
        f :: MaxiExpr -> Maybe MaxiExpr
        f (LEQ (Const x) (Const y)) = Just $ BoolConst (x <= y)
        f (LEQ (Frac x) (Frac y)) = Just $ BoolConst (x <= y)
        f _ = Nothing


--allRules :: LabeledStrategy MaxiExpr
--allRules = label "strategy many expr" $ many (maxiRule .|. doubleRule .|. plusRule .|. ifRule .|. gtrRule)

maxiSymbol, doubleSymbol, plusSymbol, ifSymbol, gtrSymbol :: Symbol

maxiSymbol = newSymbol "maxi"
doubleSymbol = newSymbol "double"
plusSymbol = newSymbol "plus"
ifSymbol = newSymbol "if"
gtrSymbol = newSymbol "gtr"
leqSymbol = newSymbol "leq"
boolSymbol = newSymbol "boolean"
fracSymbol = newSymbol "frac"


-- maak een instance voor DoubleExpr
instance IsTerm MaxiExpr where
    toTerm (Maxi x y) = binary maxiSymbol (toTerm x) (toTerm y)
    toTerm (Double x) = unary doubleSymbol (toTerm x)
    toTerm (Plus x y) = binary plusSymbol (toTerm x) (toTerm y)
    toTerm (IF c x y) = ternary ifSymbol (toTerm c) (toTerm x) (toTerm y)
    toTerm (GTR x y) = binary gtrSymbol (toTerm x) (toTerm y)
    toTerm (LEQ x y) = binary leqSymbol (toTerm x) (toTerm y)
    toTerm (Const n) = TNum (toInteger n)
    toTerm (Frac x) = binary fracSymbol (TNum (toInteger $ numerator  x)) (TNum (toInteger $ denominator x))
    toTerm (BoolConst False) = TVar "false"
    toTerm (BoolConst True) = TVar "true"

    fromTerm (TNum x) = return (Const (fromInteger x))
--    fromTerm (TCon fracSymbol [TNum n,TNum t]) = return (fr2  (fromInteger t) (fromInteger n))
    fromTerm (TVar "false") = return (BoolConst False)
    fromTerm (TVar "true") = return (BoolConst True)
    fromTerm term = fromTermWith f term
        where
            f s [x]                 | s == doubleSymbol = return ( Double x)
            f s [x,y]               | s == maxiSymbol   = return (Maxi x y)
            f s [x,y]               | s == plusSymbol   = return (Plus x y)
            f s [c, x, y]           | s == ifSymbol = return (IF c x y)
            f s [x, y]              | s == gtrSymbol = return (GTR  x y)
            f s [x, y]              | s == leqSymbol = return (LEQ  x y)
            f s [Const t, Const n]  | s == fracSymbol = return (fr2 t n)
            f _ _ = fail "invalid expression"

allRules :: LabeledStrategy MaxiExpr
allRules = label "expr strategy" $
    maxiRule .|. doubleRule .|. plusRule .|. buggyPlusRule .|. ifRule .|. gtrRule .|. leqRule


-- improved strategy
evalStrategy :: LabeledStrategy (Context MaxiExpr)
evalStrategy = label "eval" $
    repeatS (somewhere (liftToContext allRules))


eqExpr :: MaxiExpr -> MaxiExpr -> Bool
eqExpr x y = eval x == eval y

-- Wanneer is het goal bereikt?
isDone :: MaxiExpr -> Bool
isDone (Const n) = True
isDone (Frac n) = True
isDone _ = False

doubleExercise :: Exercise MaxiExpr
doubleExercise = emptyExercise
    { exerciseId = describe "Evaluate expressions double" $
                      newId "double"
    , status = Experimental
    , strategy = evalStrategy
    , prettyPrinter = show
    , navigation = termNavigator
    , parser = readM
    , equivalence = withoutContext eqExpr
    , ready = predicate isDone
    , examples = level Easy [double1, double1a] ++ level Medium [ double2, double3, double4] ++ level Difficult [double6, double7, double8]
    }


maxiExercise :: Exercise MaxiExpr
maxiExercise = emptyExercise
    { exerciseId = describe "Evaluate expressions with maxi" $
                      newId "maxi"
    , status = Experimental
    , strategy = evalStrategy
    , prettyPrinter = show
    , navigation = termNavigator
    , parser = readM
    , equivalence = withoutContext eqExpr
    , ready = predicate isDone
    , examples = level Medium [ maxi1, maxi2, maxi3, maxi4] ++ level Difficult [maxi5, maxi6, maxi7]
    }


combinedExercise :: Exercise MaxiExpr
combinedExercise = makeExercise
    { exerciseId = describe "Evaluate expressions with maxi and double" $
                      newId "combined"
    , status = Experimental
    , strategy = evalStrategy
    , prettyPrinter = pp --show
    , similarity = (==)
    , navigation = termNavigator
    , parser = readM
    , equivalence = withoutContext eqExpr
    , ready = predicate isDone
--    , examples = level Medium [combined1, combined2, combined3, combined4] ++ level Difficult [combined11, combined12, combined13, combined14, combined15]
    }



double1 = Double (Const 3)
double1a = Double (Const 5)
double2 = Double (Double (Const 2))
double3 = Double (Double (Const 3))
double4 = Double (Double (Const 10))
double6 = Double (Double (Double (Const 5)))
double7 = Double (Double (Double (Const 6)))
double8 = Double (Double (Double (Const 7)))


maxi1 = Maxi (Const 1) (Const 5)
maxi2 = Maxi (Const 5) (Const 3)
maxi3 = Maxi (Const 2) (Const 8)
maxi4 = Maxi (Const 7) (Const 7)
maxi5 = Maxi (Maxi (Const 3) (Const 4)) (Const 5)
maxi6 = Maxi (Maxi (Const 5) (Const 4)) (Const 3)
maxi7 = Maxi (Maxi (Const 3) (Const 7)) (Const 5)

combined1 = Maxi (Const 3) maxi1
combined2 = Maxi maxi2 (Const 5)
combined3 = Maxi double1 (Const 4)
combined4 = Maxi (Const 11) (Double (Const 7))

combined11 = Maxi double1 maxi1
combined12 = Double maxi2
combined13 = Maxi maxi3 double3
combined14 = Maxi maxi4 double4
combined15 = Maxi maxi2 double2


fdouble1 = Double (fr2 3 4)
fdouble1a = Double (fr 5)
fdouble2 = Double (Double (fr2 3 4))
fdouble3 = Double (Double (fr 3))
fdouble4 = Double (Double (fr 4))
fdouble6 = Double (Double (Double (fr 5)))
fdouble7 = Double (Double (Double (fr 6)))
fdouble8 = Double (Double (Double (fr 7)))


fmaxi1 = Maxi (fr 1) (fr 5)
fmaxi2 = Maxi (fr 5) (fr 3)
fmaxi3 = Maxi (fr 2) (fr 8)
fmaxi4 = Maxi (fr 7) (fr 7)
fmaxi5 = Maxi (Maxi (fr 3) (fr 4)) (fr 5)
fmaxi6 = Maxi (Maxi (fr 5) (fr 4)) (fr 3)
fmaxi7 = Maxi (Maxi (fr 3) (fr 7)) (fr 5)

fcombined1 = Maxi (fr 3) fmaxi1
fcombined2 = Maxi fmaxi2 (fr 5)
fcombined3 = Maxi fdouble1 (fr 4)
fcombined4 = Maxi (fr 11) (Double (fr 7))

fcombined11 = Maxi fdouble1 fmaxi1
fcombined12 = Double fmaxi2
fcombined13 = Maxi fmaxi3 fdouble3
fcombined14 = Maxi fmaxi4 fdouble4
fcombined15 = Maxi fmaxi2 fdouble2


maxidr :: DomainReasoner
maxidr = describe "Domain reasoner for Hutton chapter 1 exercise 1" (newDomainReasoner "eval")
    { exercises = [Some doubleExercise, Some maxiExercise, Some combinedExercise]
    }



