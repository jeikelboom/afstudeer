module Main where

import Scenarios.ScenarioExprEval
import Scenarios.FastStudent
import Scenarios.ScenarioLinEq

import System.Directory
import System.Environment
import System.IO
import System.Console.GetOpt
import Data.Traversable
import Data.Foldable
import Data.Maybe(fromMaybe)

import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty

exprEval = "data/learningCurveExprEval.json"
fastStudent = "data/fastStudent.json"
slowStudent = "data/slowStudent.json"
normalStudent = "data/normalStudent.json"
buggyStudent  = "data/buggyStudent.json"
linEqFileBuggy = "data/LearningCurveLinEqBuggy.json"
linEqFile = "data/LearningCurveLinEq.json"

main :: IO ()
main = do
    wf exprEval learningCurve
    wf linEqFileBuggy buggyLearningCurveLinEq
    wf linEqFile learningCurveLinEq
    wf fastStudent learningCurveFastStudent
    wf slowStudent learningCurveSlowStudent
    wf normalStudent learningCurveNormalStudent
    wf buggyStudent learningCurveBuggyStudent
    putStrLn "Done"


wf file mdl = writeFile file $ show $ pp_value $ toJSON mdl

--jsonLearningCurve :: String
--jsonLearningCurve = show $ pp_value $ toJSON learningCurve
