{-#LANGUAGE GADTs #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE DeriveDataTypeable #-}
module StudentModel.ProgressIndicators where

import Algebra.Lattice as LA
import Algebra.PartialOrd as PO
import Data.Typeable
import Data.Data
import Data.List
import Text.Printf
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty
import qualified Data.Map.Strict as Map

-- comparable comes with Algebra.PartialOrd in 1.6
class (Eq a, LA.BoundedJoinSemiLattice a, LA.MeetSemiLattice a,  PO.PartialOrd a) => ProgressIndicator a where
    comparable :: a -> a -> Bool
    (<++) :: a -> a -> a



infixl 6 <++
-------------------------------------------------------------------------------------
-- simple atomic progress Indicator
-- canonical form: bottom is not stored but implicit
canonicalize  :: PrInd -> PrInd
canonicalize PiBottom = PiBottom
canonicalize (PiCount name n)  | n <= 0 = PiBottom
                             | otherwise = PiCount name n
canonicalize (PiBloom name n)| n <= Ignorant = PiBottom
                             | otherwise = PiBloom name n
canonicalize (PiBool name)   = PiBool name

canonicalize (PiPV name m)   = if Map.null cm then PiBottom else PiPV name cm
    where
        cm =Map.filter (/= bottom) $ Map.map canonicalize m

data Bloom = Ignorant | Knowledge | Comprehension | Application | Analysis | Synthesis | Evaluation
    deriving (Eq, Ord, Show, Read, Typeable, Data)

instance LA.MeetSemiLattice Bloom where
    a /\ b = min a b
instance LA.JoinSemiLattice Bloom where
    a\/ b = max a b
instance LA.BoundedJoinSemiLattice Bloom where
    bottom = Ignorant
instance PO.PartialOrd Bloom where
    leq x y = x <= y

data PrInd where
    PiBottom :: PrInd
    PiCount :: String -> Int -> PrInd
    PiBloom :: String -> Bloom -> PrInd
    PiBool ::  String -> PrInd
    PiPV :: String ->  Map.Map String PrInd  -> PrInd
    deriving (Eq, Ord, Show, Read, Typeable, Data)

getKey :: PrInd -> String
getKey (PiCount name _) = name
getKey (PiBloom name _) = name
getKey (PiBool name) = name
getKey (PiPV name _) = name
getKey PiBottom = "bottom"

instance LA.MeetSemiLattice PrInd where
    PiBottom /\ _ = PiBottom
    _ /\ PiBottom = PiBottom
    PiCount n1 x /\ PiCount n2 y        | n1 == n2 = PiCount n1 $ min x y -- meet/min/and
                                    | otherwise = error $ printf "Cannot /\\ %s with %s" n1 n2
    PiBloom n1 x /\ PiBloom n2 y    | n1 == n2 = PiBloom n1 $ x /\ y
                                    | otherwise = error $ printf "Cannot /\\ %s with %s" n1 n2
    PiBool n1 /\ PiBool n2          | n1 == n2 = PiBool n1
                                    | otherwise = error $ printf "Cannot /\\ %s with %s" n1 n2
    PiPV n1 pv1 /\ PiPV n2 pv2      = canonicalize $ PiPV n1 $ Map.intersectionWith (/\) pv1 pv2
    _ /\ _                          = error $ printf "impossible \\/  "

instance LA.JoinSemiLattice PrInd where
    PiBottom \/ x = x
    x \/ PiBottom = x
    PiCount n1 x \/ PiCount n2 y        | n1 == n2 = PiCount n1 $ max x y -- join/max/or
                                    | otherwise = error $ printf "Cannot \\/ %s with %s" n1 n2
    PiBloom n1 x \/ PiBloom n2 y    | n1 == n2 = PiBloom n1 $ x \/ y
                                    | otherwise = error $ printf "Cannot \\/ %s with %s" n1 n2
    PiBool n1 \/ PiBool n2          | n1 == n2 = PiBool n1
                                    | otherwise = error $ printf "Cannot \\/ %s with %s" n1 n2
    PiPV n1 pv1 \/ PiPV n2 pv2      = canonicalize $ PiPV n1 $ Map.unionWith (\/) pv1 pv2
    _ \/ _                                  = error $ printf "impossible \\/  "
-- neutral element in join bottom \/ x == x
-- null element for meet /\
instance LA.BoundedJoinSemiLattice PrInd where
    bottom = PiBottom

-- We use joinLeq as leq.
-- meetLeq the becomes som sort of gec.
-- join en meet both generate a partial ordering.
instance PO.PartialOrd PrInd where
    leq  (PiCount n1 x) (PiCount n2 y) | n1 == n2 = x <= y
    leq  (PiBloom n1 x) (PiBloom n2 y) | n1 == n2 = leq x y
    leq PiBottom PiBottom = True
    leq x y = canonicalize (y \/ x) ==  canonicalize y

instance ProgressIndicator PrInd where
    comparable (PiCount n1 x) (PiCount n2 y)    | n1 == n2 = True
                                            | otherwise = error $ printf "Cannot comparable %s with %s" n1 n2
    comparable x y = leq x y || leq y x
    PiCount n1 n <++ PiCount n2 m   | n1 == n2 = PiCount n1 (n + m)
                                | otherwise = error $ printf "Cannot <++ %s with %s" n1 n2
    PiBottom <++ x = x
    PiBool n1 <++ x = PiBool n1
    PiPV n1 pv1 <++ PiPV n2 pv2 | n1 == n2 = canonicalize $ PiPV n1 $ Map.unionWith (<++) pv1 pv2
                                | otherwise = error $ printf "Cannot <++ %s with %s" n1 n2

-- utility functions
{- | directly adress a nested value
-}
getValue :: [PrInd] -> PrInd -> PrInd
getValue [key] (PiCount name n)        | name == getKey key = PiCount name n
                                     | otherwise = PiBottom
getValue [key] (PiBloom name n)      | name == getKey key = PiBloom name n
                                     | otherwise = PiBottom
getValue [key] (PiBool name)         | name == getKey key = PiBool name
                                     | otherwise = PiBottom
getValue [key1]        (PiPV n m) =  Map.findWithDefault PiBottom (getKey key1) m
getValue [key0, key1]   (PiPV n m) | getKey key0 == n =  Map.findWithDefault PiBottom (getKey key1) m
getValue (key0:key1:keys) (PiPV n m) | getKey key0 == n = getValue (key1:keys) $ Map.findWithDefault PiBottom (getKey key1) m
getValue _ _ = PiBottom

{- | create a nested value
-}
mkValue :: [String] -> PrInd -> PrInd
mkValue [] val =  val
mkValue (key :keys) val = PiPV key $ Map.singleton (getKey v) v
    where v = mkValue keys val

mkValue2 :: [PrInd] -> PrInd -> PrInd
mkValue2 [] val =  val
mkValue2 (key :keys) val = PiPV (getKey key) $ Map.singleton (getKey v) v
    where v = mkValue2 keys val

{- | insert a PrInd in a map
-}
insrt :: PrInd -> Map.Map String PrInd -> Map.Map String PrInd
insrt value  = Map.insert  (getKey value) value

--mkTrue :: String -> (String, PrInd)
--mkTrue a = (a, PiBool a)

{- | Create a sub table (a PiPV).
-}
mkSub :: String -> PrInd
mkSub nm = PiPV nm  Map.empty

{- | add values after creating a PiPV
-}
with :: PrInd -> PrInd -> PrInd
with (PiPV nm map) value = PiPV nm $ insrt value  map
infixl 6 `with`

plus = with
infixr 6 `plus`

inside :: PrInd -> PrInd -> PrInd
inside value  (PiPV nm map) = PiPV nm $ insrt value  map
infixl 6 `inside`

{-| show JSON value
-}
shj ::  Data a => a -> IO ()
shj = print . pp_value . toJSON

class HasPrInd a where
    getPrInd :: a -> PrInd
    setPrInd :: a -> PrInd -> a
    getName :: a -> String


instance HasPrInd PrInd where
    getPrInd = id
    setPrInd _ a = a
    getName = getKey


lift2HasPrInd :: (HasPrInd a, HasPrInd b) => (PrInd ->PrInd -> PrInd) -> a -> b -> a
lift2HasPrInd f c1 c2 = setPrInd c1 $ f (getPrInd c1) (getPrInd c2)

joinHPI :: (HasPrInd a, HasPrInd b) => a -> b -> a
joinHPI = lift2HasPrInd  (\/)

meetHPI :: (HasPrInd a, HasPrInd b) => a -> b -> a
meetHPI = lift2HasPrInd  (/\)

leqHPI :: (HasPrInd a, HasPrInd b) => a -> b -> Bool
leqHPI c1 c2 = leq (getPrInd c1) (getPrInd c2)

joinList :: [PrInd] -> PrInd
joinList = foldl (\/) PiBottom




