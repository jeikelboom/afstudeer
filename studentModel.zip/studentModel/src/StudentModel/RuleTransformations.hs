{-#LANGUAGE GADTs #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE DeriveDataTypeable #-}
module StudentModel.RuleTransformations where

import Control.Monad.Trans.State.Strict
import Data.Typeable
import Data.Data
import Data.List
import Text.Printf
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators



newtype Model           = Model{model :: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Model where
    getPrInd = model
    setPrInd _ pi = Model{model=pi}
    getName = getKey . model


newtype Step            = Step{step :: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Step where
    getPrInd = step
    setPrInd _ pi = Step{step=pi}
    getName = getKey . step

newtype FoldHelper b    = FoldHelper {fh :: b -> PrInd -> b}
newtype PiPredicate  a   = PiPredicate{predicate :: a -> Bool}

notP :: PiPredicate  a -> PiPredicate  a
notP PiPredicate{predicate=p} = PiPredicate{predicate= not . p}

stepProcessor ::  (Model -> Model) -> Model -> Step  -> Model
stepProcessor pr Model{model=m} Step{step=s} =  pr Model{model = m <++ s}

-- Apply a fold over a datastructure one level deep
piFold :: FoldHelper b -> b -> PrInd -> b
piFold FoldHelper {fh=fh} val (PiPV nam mp) = Map.foldl fh val2 mp where val2 = fh val (PiPV nam mp)
piFold FoldHelper {fh=fh} val pi = fh val pi

piList :: (HasPrInd a) => PiPredicate PrInd -> a -> [PrInd]
piList PiPredicate{predicate=pred} pi= piFold hlp [] (getPrInd pi) where
    hlp = FoldHelper{fh = \lst pi' -> if pred pi' then pi':lst else lst }


hasName :: (HasPrInd a) => String -> PiPredicate a
hasName s = PiPredicate{predicate= \pi -> s == getKey (getPrInd pi)}

apply :: a -> PiPredicate a -> Bool
apply a PiPredicate{predicate=p} = p a

apply2 = flip apply



-- Apply a fold through the whole thing
-- (Maybe not a good idea)
--piFoldDeep :: FoldHelper b -> b -> PrInd -> b
--piFoldDeep FoldHelper {fh=fh} val (PiPV nam mp) = Map.foldl (piFoldDeep  FoldHelper{fh=fh}) val2 mp where val2 = fh val (PiPV nam mp)
--piFoldDeep FoldHelper {fh=fh} val pi = fh val pi

-- Map
-- (Maybe not a good idea)
--piMap :: (PrInd -> PrInd) -> PrInd -> PrInd
--piMap f (PiPV nam mp) = canonicalize $ PiPV nam (Map.map f mp)
--piMap f p = f p


--piFilter :: (HasPrInd a) =>  PiPredicate -> a -> PrInd
--piFilter pred ds = case getPrInd ds of
--    PiBottom -> PiBottom
--    x@(PiInt _ _) -> if apply pred ds then x else PiBottom
--    x@(PiBool _)  -> if apply pred ds then x  else PiBottom
--    (PiPV nam mp) -> canonicalize $ PiPV nam (Map.map (piFilter pred) mp)


--piFilter :: (PrInd -> Bool) -> PrInd -> PrInd
--piFilter pred (PiPV nam mp) = canonicalize $ PiPV nam (Map.map (fltr pred) mp) where
--    fltr pred pi = if pred pi then pi else PiBottom
--piFilter pred pi = fltr pred pi where
--    fltr pred pi = if pred pi then pi else PiBottom







