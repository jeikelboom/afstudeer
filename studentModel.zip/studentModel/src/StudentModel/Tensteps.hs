{-#LANGUAGE GADTs #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE DeriveDataTypeable #-}
module StudentModel.Tensteps where

import Algebra.Lattice as LA
import Algebra.PartialOrd as PO
import Data.Typeable
import Data.Data
import Data.List
import Text.Printf
import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations

-- educational state for TenSteps
esModel                 = mkSub     "ES.model"                  -- top level model
esStudent               = mkSub     "ES.student"                -- the student model or an increment thereof
esPrerequisite          = mkSub     "ES.prerequisite"           -- list of prerquisites
esObjective             = mkSub     "ES.objective"              -- list of objectives
esSuccessCriteria       = mkSub     "ES.successCriteria"        -- exercise success criteria
esFailureCriteria       = mkSub     "ES.failureCriteria"        -- exercise success criteria

-- Exercise states
esEnrolled              = PiBool    "ES.enrolled"               -- OK you have to pay
esFinished              = PiBool    "ES.finished"               -- finished (with or without errors
esSuccess               = PiBool    "ES.success"                -- finished (without errors)
esFailure               = PiBool    "ES.failure"                -- finished (without meeting objectives)
esError                 = PiBool    "ES.error"                  -- finished (with help or errors)
esDone                  = PiBool    "ES.done"                   -- exercise completely done (to make rules idempotent)

esIsTaskClass           = PiBool    "ES.isTaskClass"            -- type of object
esIsLearningTask        = PiBool    "ES.isLearningTask"         -- type of object
esIsPartTask            = PiBool    "ES.isPartTask"

esReady                 = PiBool    "ES.ready"                  -- The student can take this exercise
esTooEasy               = PiBool    "ES.tooEasy"

-- Domain Reasoner
drCreated               = PiBool    "DR.created"
drRules                 = mkSub     "DR.Rules"                  -- Rules executed success
drExpected              = mkSub     "DR.Rules"
drSimilar               = mkSub     "DR.Rules"
drDetour                = mkSub     "DR.Rules"
drNotEquivalent         = mkSub     "DR.Buggy"                  -- Rules indicating bugs
drBuggy                 = mkSub     "DR.Buggy"
drOneFirst              = mkSub     "DR.oneFirst"


mkTaskClass s           = mkSub s `with` esIsTaskClass
mkLearningTask s        = mkSub s `with` esIsLearningTask
mkPartTask s            = mkSub s `with` esIsPartTask

--ruleProcessor :: Model -> Model
--ruleProcessor = rp1


rp2 :: Model -> Model
rp2 mdl@Model{model=pi} = Model $ (\/) pi (joinList (inference allRules mdl))

rp2a :: PrInd -> PrInd
rp2a pi = pi \/ joinList (inference allRules (Model pi))

rp2afixpoint pi = LA.lfpFrom pi rp2a

rp2bfixpoint = rp2a . rp2a .rp2a


rp3 :: Model -> Model
rp3 mdl@Model{model=pi} = Model $ rp2afixpoint pi



inference :: [Rule] -> Model -> [PrInd]
inference ruleBase mdl = do
    tclass <- getTaskClasses mdl
    ltask <- getLearningTask tclass
    return $ executeRules (mdl, getStudent mdl, tclass, ltask) ruleBase



type RuleArguments = (Model, Student, TaskClass, LearningTask)

type RulePredicate = PiPredicate RuleArguments

newtype DerivedFact = DerivedFact{result:: RuleArguments -> PrInd }

data Rule = RL [RulePredicate] [DerivedFact]
(=->) :: [RulePredicate] -> [DerivedFact] -> Rule
(=->) = RL


executeRules :: RuleArguments -> [Rule] -> PrInd
executeRules args rules = foldl (\/) PiBottom (map (executeRule args) rules)

executeRule :: RuleArguments -> Rule -> PrInd
executeRule args (RL preds facts) = if evalPreds args preds then evalFacts args facts else PiBottom

evalPreds :: RuleArguments -> [RulePredicate] -> Bool
evalPreds args  = all (apply args)

evalFacts:: RuleArguments -> [DerivedFact] -> PrInd
evalFacts args facts = foldl (\/) PiBottom (map (evalFact args) facts)

evalFact :: RuleArguments -> DerivedFact -> PrInd
evalFact args DerivedFact{result=r} = r args


naming :: [String] -> PrInd -> [String]
naming ns pi = getKey pi : ns

newtype TaskClass       = TaskClass{tc :: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd TaskClass where
    getPrInd = tc
    setPrInd _ pi = TaskClass{tc=pi}
    getName = getKey . tc

newtype LearningTask    = LearningTask{lt :: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd LearningTask where
    getPrInd = lt
    setPrInd _ pi = LearningTask{lt=pi}
    getName = getKey . lt

newtype Student         = Student{student :: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Student where
    getPrInd = student
    setPrInd _ pi = Student{student=pi}
    getName = getKey . student

newtype Criteria      = Criteria{criteria:: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Criteria where
    getPrInd = criteria
    setPrInd _ pi = Criteria{criteria=pi}
    getName = getKey . criteria

newtype Objectives      = Objectives{objectives:: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Objectives where
    getPrInd = objectives
    setPrInd _ pi = Objectives{objectives=pi}
    getName = getKey . objectives

newtype Prerequisites   = Prerequisites{preq:: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Prerequisites where
    getPrInd = preq
    setPrInd _ pi = Prerequisites{preq=pi}
    getName = getKey . preq

newtype Progress   = Progress{progress:: PrInd}
    deriving (Eq, Ord, Show, Read, Typeable, Data)
instance HasPrInd Progress where
    getPrInd = progress
    setPrInd _ pi = Progress{progress=pi}
    getName = getKey . progress

isTaskClass, isLearningTask :: PiPredicate PrInd

getTaskClasses :: Model -> [TaskClass]
getTaskClasses model = map TaskClass $ piList isTaskClass model

getLearningTask :: TaskClass -> [LearningTask]
getLearningTask taskClass = map LearningTask $ piList isLearningTask taskClass

isTaskClass = PiPredicate{predicate=hlp} where
    hlp (PiPV nam mp) = Map.member (getKey esIsTaskClass) mp
    hlp _ = False

isLearningTask = PiPredicate{predicate=hlp} where
    hlp (PiPV nam mp) = Map.member (getKey esIsLearningTask) mp
    hlp _ = False

getSuccessCriteria :: HasPrInd a => a -> Criteria
getSuccessCriteria component = Criteria $ getValue [pi, esSuccessCriteria] pi
    where pi = getPrInd component

getFailureCritera :: HasPrInd a => a -> Criteria
getFailureCritera component = Criteria $ getValue [pi, esFailureCriteria] pi
                     where pi = getPrInd component

getPrerequisites :: HasPrInd a => a -> Prerequisites
getPrerequisites component = Prerequisites $ getValue [pi, esPrerequisite] pi
    where pi = getPrInd component

getObjectives :: HasPrInd a => a -> Objectives
getObjectives component = Objectives $ getValue [pi, esObjective] pi
    where pi = getPrInd component

getProgress :: HasPrInd a => a -> Progress
getProgress component = Progress $ getValue [pi, drRules] pi
    where pi = getPrInd component

getBuggy :: HasPrInd a => a -> Progress
getBuggy component = Progress $ getValue [pi, drBuggy] pi
    where pi = getPrInd component

getStudent :: HasPrInd a => a -> Student
getStudent component = Student $ getValue [pi, esStudent] pi
    where pi = getPrInd component




{-
State changes
INIT    -> READY (prerequisites are met)
READY   -> BUSY (step feedback)
READY   -> FINI (step feedback)
INIT    -> BUSY (step feedback)
BUSY    -> FINI (step feedback)
FINI    -> ERROR
FINI    -> SUCCESS
FINI    -> FAILED
ERROR   -> DONE
SUCCESS -> DONE
FAILED  -> DONE
-}
data LearningTaskState = INIT | READY | BUSY | FINI | SUCCESS | FAILED | ERROR | DONE
    deriving (Show, Eq, Read)

-- Kripke valuation function
-- Determine state of a learning task
-- Input is a substructure representing a learning task.
ltState :: LearningTask -> LearningTaskState
ltState LearningTask{lt=lt}    | isSet esDone lt = DONE
            | isSet esError lt = ERROR
            | isSet esSuccess lt = SUCCESS
            | isSet esFinished lt = FINI
            | isSet drCreated lt = BUSY
            | isSet esReady lt = READY
            | otherwise = INIT
        where
            isSet :: PrInd -> PrInd -> Bool
            isSet pi (PiPV _ mp) = Map.member (getKey pi) mp
            isSet pi x = error ("cannot find " ++ getKey pi ++ " in " ++ getKey x)


-- vocabulary of predicates and Facts

{-
rules:
learningTaskErrorRule :  FINI && esProgress contains esError =-> ERROR
learningTaskSuccessRule: FINI && not esProgress contains esErrors && esProgress >= esObjectives =-> model <++ esStudent, SUCCESS
abandonedRule:           FINI && not esProgress contains esErrors && not esProgress >= esObjectives =-> FAILED  (melding)
ERROR -> DONE
SUCCESS -> DONE
FAILED -> DONE
-}
allRules = [learningTaskBuggyRule, learningTaskErrorRule, learningTaskSuccessRule, abandonedRule, readyRule, backward]

learningTaskState :: LearningTaskState -> RulePredicate
learningTaskState state = PiPredicate{predicate = \(_,_,_,ltask) -> ltState ltask == state}

taskState  :: PrInd -> DerivedFact
taskState stat = DerivedFact{result = \(mdl,_,tclass,ltask) -> mkValue2 (mdl +: tclass +: ltask +: []) stat}
(+:) :: (HasPrInd a) => a -> [PrInd] -> [PrInd]
a +: b = getPrInd a : b
infixr 6 +:

taskInError :: DerivedFact
taskInError = taskState esError
taskSuccess = taskState esSuccess
taskFailed = taskState esFailure
taskReady = taskState esReady
taskTooEasy = taskState esTooEasy

obj2student :: PrInd -> PrInd
obj2student (PiPV s v) = PiPV (getKey esStudent) v
obj2student _ = PiBottom


learningTaskHasErrors :: RulePredicate
learningTaskHasErrors = PiPredicate{predicate = \(_,_,_,ltask) -> esError == getValue [lt ltask, drRules, esError] (lt ltask)}

learningTaskBuggy :: RulePredicate
learningTaskBuggy = PiPredicate{predicate = \(_,_,_,ltask) -> PiBottom /= getPrInd ( getBuggy ltask)}
--PiBottom /= (getPrInd $ meetHPI (getFailureCritera ltask) (getBuggy ltask)))}
learningTaskSucces = notP learningTaskHasErrors
learningTaskNotBuggy = notP learningTaskBuggy

successCriteriaMet :: RulePredicate
successCriteriaMet = PiPredicate{predicate = \(_,_,_,ltask) -> leqHPI (getSuccessCriteria ltask) (getProgress ltask)}

prerequisitesMet :: RulePredicate
prerequisitesMet = PiPredicate{predicate = \(_,stdnt,_,ltask) -> leqHPI (getPrerequisites ltask) stdnt}

objectivesMet :: RulePredicate
objectivesMet = PiPredicate{predicate = \(_,stdnt,_,ltask) -> leqHPI (getObjectives ltask) stdnt}

updateStudentModel  :: DerivedFact
updateStudentModel = DerivedFact{result = \(mdl,_,tclass,ltask) -> mkValue2 [esModel] (obj2student $ objectives $ getObjectives ltask)}

updateStudentModelPreq  :: DerivedFact
--updateStudentModel = DerivedFact{result = (\(mdl,_,tclass,ltask) -> mkValue2 [esModel] (objectives $ getObjectives ltask))}
updateStudentModelPreq = DerivedFact{result = \(mdl,_,tclass,ltask) -> mkValue2 [esModel] (obj2student $ preq $ getPrerequisites ltask)}



updateStudentModelBuggy  :: DerivedFact
--updateStudentModel = DerivedFact{result = (\(mdl,_,tclass,ltask) -> mkValue2 [esModel] (objectives $ getObjectives ltask))}
updateStudentModelBuggy = DerivedFact{result = \(mdl,_,tclass,ltask) -> mkValue2 [esModel] (obj2student $ progress $ getBuggy ltask)}

--buggyStudentModel :: DerivedFact

learningTaskBuggyRule, learningTaskErrorRule, learningTaskSuccessRule, abandonedRule, readyRule :: Rule
learningTaskBuggyRule =     [learningTaskState FINI, learningTaskBuggy] =-> [taskInError, updateStudentModelBuggy]
learningTaskErrorRule =     [learningTaskState FINI, learningTaskNotBuggy, learningTaskHasErrors] =-> [taskInError]
learningTaskSuccessRule =   [learningTaskState FINI, learningTaskNotBuggy, learningTaskSucces, successCriteriaMet] =-> [taskSuccess, updateStudentModel, updateStudentModelPreq]
abandonedRule =             [learningTaskState FINI, learningTaskNotBuggy, learningTaskSucces, notP successCriteriaMet] =-> [taskFailed]
readyRule =                 [learningTaskState INIT, prerequisitesMet] =-> [taskReady]

backward = [objectivesMet] =-> [taskTooEasy, updateStudentModelPreq]


