{-# LANGUAGE DeriveDataTypeable #-}
module Scenarios.RunScenario where

import Data.Typeable
import Data.Data

import DomainReasoners.MaxiDouble
import Scenarios.Scenario1
import Algebra.Lattice as LA
import Algebra.Lattice.Ordered as OR
import Algebra.PartialOrd as PO
import qualified Data.Map.Strict as Map

import StudentModel.ProgressIndicators
import StudentModel.RuleTransformations
import StudentModel.Tensteps
import DomainReasoners.LineairEquations
import Scenarios.Vocabulary
import Data.Traversable
import Data.Foldable
import Data.Maybe(fromMaybe)

import Text.JSON
import Text.JSON.Generic
import Text.JSON.Pretty

--scenario4Out = "data/Scenario4.json"
--scenario4Trc = "data/Scenario4.trc"
--scenLinEqTrc = "data/ScenLinEq.trc"

--data TraceRecord t = DR String | CR {tcnam :: String, ltnam :: String, exp :: String, dr:: t} | FN
--    deriving (Eq, Show, Read, Typeable, Data)
--
--
--
--
--rt :: String -> TraceRecord
--rt = read
--
--runInput :: [String] -> [Model]
--runInput s = learningCurve
--
--readLines :: FilePath  -> IO [String]
--readLines file = do
--    f <- readFile file
--    return $ lines f
--
--readTrace :: FilePath -> IO [TraceRecord ]
--readTrace f = do
--    lines <- readLines f
--    return $ map rt lines
--





{-| show JSON value
-}
shj ::  Data a => a -> IO ()
shj = putStrLn  . show . pp_value . toJSON

writeLines :: FilePath -> [String] -> IO()
writeLines f d = writeFile f $ unlines d

printLines ::[String] -> IO()
printLines  = putStrLn . unlines

pt :: FilePath  -> IO()
pt f = do
    trc <- readTrace f
    printLines $ map show trc





